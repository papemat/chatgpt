#!/bin/bash
echo "Avvio TokIntel CLI..."
python3 run_tokintel.py --config config.yaml --input demo_input/