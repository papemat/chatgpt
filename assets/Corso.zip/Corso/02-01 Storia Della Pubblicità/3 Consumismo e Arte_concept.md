Invenzione della stampa a caratteri mobili (1455) → Ha dato origine alla pubblicità su carta stampata

Primi annunci pubblicitari su carta stampata da William Caxton (1477) → Derivato dall'invenzione della stampa a caratteri mobili
   → Ha segnato l'inizio della pubblicità moderna

Esplosione della pubblicità nel tardo Settecento → Conseguito lo sviluppo di diversi mezzi pubblicitari, come le concessionarie e i cataloghi per corrispondenza

Nascono le prime concessionarie pubblicitarie in Francia (metà XIX secolo) → Sviluppato durante l'esplosione della pubblicità nel tardo Settecento
   → Ha permesso una diffusione più ampia e mirata dei messaggi pubblicitari

Cataloghi per corrispondenza (1895) → Evoluzione del sistema delle concessionarie pubblicitarie
   → Ha ampliato le possibilità di promozione dei prodotti attraverso l'invio di cataloghi via posta

Evoluzione del marketing attraverso la rivoluzione industriale e l'avvento della televisione → Continua adattamento della pubblicità ai nuovi mezzi tecnologici
   → Ha permesso una comunicazione più diretta e coinvolgente con il consumatore

Utilizzo di testimonial e strategie persuasive per aumentare il consumo dei prodotti → Concentrazione attuale del marketing
   → Mirata a creare preferenza del consumatore e stimolare l'acquisto dei prodotti