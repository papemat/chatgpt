Titolo: Evoluzione della Pubblicità: Dall'Emotività ai Valori Aziendali

Paragrafo di sintesi:
Nel corso degli anni, la pubblicità ha attraversato diverse fasi di evoluzione. Negli anni '80, si concentrava sui valori familiari, sfruttando la forza del sentimento in paesi come l'Italia. Negli anni '90, con il consumatore sempre più attento e l'espansione dei centri commerciali e supermercati, la pubblicità si spostò verso un approccio meno emotivo e più focalizzato sulle caratteristiche del prodotto. La rivoluzione digitale degli anni 2000 ha portato a una maggiore attenzione all'informazione e alla trasparenza, con le persone che diventano parte integrante e protagoniste della pubblicità. Oggi, le aziende si concentrano sull'etica e sui valori delle persone che formano le aziende stesse, creando una connessione emotiva più profonda con il consumatore.

Concetti chiave in ordine cronologico:
1. Valori familiari nella pubblicità degli anni '80
2. Espansione dei centri commerciali e supermercati negli anni '90
3. Consumatore sempre più attento e richiesta di caratteristiche del prodotto
4. Rivoluzione digitale e trasparenza negli anni 2000
5. Aziende che si concentrano sull'etica e sui valori delle persone
6. Connessione emotiva profonda tra azienda e consumatore
7. Ruolo fondamentale del customer care e recensioni online