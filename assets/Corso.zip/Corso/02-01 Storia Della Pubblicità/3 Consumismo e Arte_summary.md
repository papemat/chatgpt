Titolo: Storia della Pubblicità: Dall'Invenzione della Stampa al Marketing Moderno

Paragrafo di sintesi:
La pubblicità è evoluta significativamente dal suo inizio nel 1455, grazie all'invenzione della stampa a caratteri mobili da parte di Gutenberg. Negli anni successivi, la pubblicità si è sviluppata attraverso diversi mezzi, tra cui l'uso delle concessionarie pubblicitarie e i cataloghi per corrispondenza. La pubblicità ha iniziato ad essere riconosciuta come un vero e proprio servizio commerciale nel XIX secolo, e ha continuato a evolversi attraverso la rivoluzione industriale e l'avvento della televisione. Oggi, il marketing si concentra su strategie di persuasione per aumentare il consumo dei prodotti e favorire la preferenza del consumatore.

Concetti chiave:
1. Invenzione della stampa a caratteri mobili (1455)
2. Primi annunci pubblicitari su carta stampata da William Caxton (1477)
3. Esplosione della pubblicità nel tardo Settecento
4. Nascono le prime concessionarie pubblicitarie in Francia (metà XIX secolo)
5. Cataloghi per corrispondenza (1895)
6. Evoluzione del marketing attraverso la rivoluzione industriale e l'avvento della televisione
7. Utilizzo di testimonial e strategie persuasive per aumentare il consumo dei prodotti