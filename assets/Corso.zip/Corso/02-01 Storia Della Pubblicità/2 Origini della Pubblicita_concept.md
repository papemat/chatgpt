- Comunicazione tra venditori e clienti attraverso l'esibizione fisica di prodotti e servizi
  - Messaggi pubblicitari a voce

- Insegne per promuovere locali o servizi
  - Giornali (bellus) come antenati dei giornali moderni
    - Affissioni per diffondere messaggi pubblicitari

- Monete come mezzo di propaganda politica e religiosa
  - Comunicazione elettronica nelle città, come a Pompei

- Evoluzione dei mezzi di comunicazione in base ai bisogni e ai desideri delle persone
  - Influenza degli strumenti di comunicazione sulle strategie pubblicitarie e di marketing
    - Utilizzo dei social network per promuovere prodotti e servizi nell'era digitale