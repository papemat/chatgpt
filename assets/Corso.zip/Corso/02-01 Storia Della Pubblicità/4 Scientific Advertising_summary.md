1. L'influenza della belle époque sulla pubblicità italiana

2. In Italia, la pubblicità degli anni venti era influenzata dalla belle époque francese. Mentre gli americani spingevano fortemente il consumismo per massimizzare le vendite, in Italia la pubblicità si univa all'arte per creare messaggi eleganti e raffinati. Il copywriting divenne una tecnica importante per stimolare i desideri delle persone e aumentare le vendite.

3. Concetti chiave:
- Influenza francese sulla pubblicità italiana
- Unione di arte e pubblicità
- Differenza con l'approccio americano basato sul consumismo
- Importanza del copywriting per stimolare i desideri delle persone
- Aumento delle vendite grazie alla pubblicità efficace
- Sviluppo della redazione pubblicitaria come tecnica comunicativa