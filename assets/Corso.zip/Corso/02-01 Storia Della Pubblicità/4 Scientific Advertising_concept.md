Influenza della belle époque sulla pubblicità italiana
    → Influenza francese sulla pubblicità italiana
        → Unione di arte e pubblicità
            → Differenza con l'approccio americano basato sul consumismo
                → Importanza del copywriting per stimolare i desideri delle persone
                    → Aumento delle vendite grazie alla pubblicità efficace
                        → Sviluppo della redazione pubblicitaria come tecnica comunicativa