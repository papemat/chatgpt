Titolo: La Storia della Pubblicità: Dall'Arte alla Comunicazione di Successo

Paragrafo di sintesi:
La pubblicità ha attraversato un lungo percorso dal passaggio dall'arte alla comunicazione professionale, influenzata da culture diverse e cambiamenti economici. Armando Testa è stato pioniere in Italia, seguito da innovatori come Bill Bernbach che hanno sviluppato nuovi approcci creativi. La pubblicità ha evoluto team di lavoro specializzati, come copywriter, art director e account manager, per creare campagne efficaci. L'USP (Unique Selling Proposition) è diventata una strategia chiave per differenziarsi e comunicare un beneficio unico al consumatore.

Concetti chiave in ordine cronologico:
1. Armando Testa apre un'agenzia pubblicitaria in Italia nel 1946, segnando il passaggio dall'arte alla pubblicità professionale.
2. L'influenza della cultura americana e la necessità di adattare le strategie pubblicitarie al contesto italiano.
3. La nascita del carosello in Italia nel 1957 come forma di intrattenimento che include un messaggio pubblicitario.
4. La campagna "Think Small" di Volkswagen nel 1959, vinta come miglior campagna del ventesimo secolo, e l'introduzione del team creativo composto dall'art director e copywriter.
5. L'uso del claim "tostato" da parte delle sigarette Strike per comunicare un vantaggio competitivo.
6. La formulazione dell'USP (Unique Selling Proposition) da Rosser Reeves come strategia chiave per differenziarsi nel mercato pubblicitario.