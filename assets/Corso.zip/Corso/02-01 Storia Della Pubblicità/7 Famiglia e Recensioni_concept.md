1. Valori familiari nella pubblicità degli anni '80
   → Fase di evoluzione della pubblicità
2. Espansione dei centri commerciali e supermercati negli anni '90
   → Fase di evoluzione della pubblicità
3. Consumatore sempre più attento e richiesta di caratteristiche del prodotto
   → Consequenza dell'espansione dei centri commerciali e supermercati
4. Rivoluzione digitale e trasparenza negli anni 2000
   → Fase di evoluzione della pubblicità
5. Aziende che si concentrano sull'etica e sui valori delle persone
   → Conseguenza della rivoluzione digitale e trasparenza
6. Connessione emotiva profonda tra azienda e consumatore
   → Obiettivo delle aziende che si concentrano sull'etica e sui valori delle persone
7. Ruolo fondamentale del customer care e recensioni online
   → Aspetto della trasparenza digitale negli anni 2000