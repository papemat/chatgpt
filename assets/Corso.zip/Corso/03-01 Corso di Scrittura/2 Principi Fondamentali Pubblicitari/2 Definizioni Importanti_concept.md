La pubblicità: definizioni, tipologie e strategie

- Pubblicità
  - Comunicazione promozionale che mira a informare, persuadere o ricordare ai potenziali clienti i beni o servizi offerti da un'azienda
  - Finalità di aumentare la domanda per i prodotti o servizi

- Marketing vs. Pubblicità
  - Marketing: attività che si svolgono per soddisfare le esigenze dei clienti e creare valore per l'organizzazione
    - Include strategie, ricerca del mercato, sviluppo di prodotto, distribuzione, pricing e comunicazione
  - Pubblicità: parte specifica del marketing che si concentra sulla comunicazione

- Redattore pubblicitario (Copywriter)
  - Persona che si occupa di scrivere contenuti pubblicitari in vari formati
    - Titoli
    - Manuali
    - Mail
    - Post sui social media
    - Comunicati stampa
    - Script per video e podcast

- SEO nei contenuti pubblicitari
  - Ottimizzazione dei contenuti per motori di ricerca, in modo da aumentarne la visibilità online
  - Importante per raggiungere un pubblico più ampio e rilevante

- Obiettivo del redattore pubblicitario
  → Comunicare efficacemente le strategie aziendali alle masse
    - Informare sulle offerte, i vantaggi e le differenze rispetto ai concorrenti
    - Persuadere il pubblico a scegliere i prodotti o servizi dell'azienda
    - Ricordare al pubblico l'esistenza dei beni o servizi quando non ci sono intenzioni di acquisto immediato