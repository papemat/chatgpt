1. Caratteristiche del copywriter
   - Conoscenza della grammatica italiana
     → Evita errori nei messaggi pubblicitari
   - Desideri di mercato
     → Creazione di soluzioni specifiche a quei bisogni
   - Competenze tecniche
     → Utilizzo di vari strumenti e programmi necessari alla creazione del copy
   - Etica nel marketing
     → Comunicare in modo educativo ed etico, evitando truffe o metodi poco puliti
   - Utilità per le persone
     → Aiuta le masse a comprendere i bisogni di mercato e a trovare soluzioni efficaci

2. Il copywriter è responsabile della differenza tra un messaggio sterile e uno utile, influenzando in modo positivo o negativo le persone.