- La forma della comunicazione in pubblicità
  - La scelta del tono dipende dal target e dalla relazione con il lettore
    - Comprendere la temperatura del lettore (nuovo cliente o fedele)
      → Adattare il tono in base alla relazione con il lettore
        → Utilizzare il giusto tipo di pressione
          → Considerare il contesto e l'ambiente circostante
            → Evitare di copiare tecniche pubblicitarie da culture diverse