Gillette e la Mascolinità Tossica

1. Pubblicità storica degli anni Ottanta:
   - "Gillette, the best a man can get"
2. Nuova pubblicità:
   - "You're looking sharp"
     → Affronta la mascolinità tossica
3. Movimento Me Too e #TimesUp:
   - Allegazioni di molestie e abuso sessuale
4. Riconciliazione tra vecchio e nuovo archetipo pubblicitario:
   - Riflessione sull'archetipo più vicino e lontano dalla realtà attuale
5. Allenamento alla narrazione attraverso cambiamenti nell'ordine degli elementi:
   → Storia di Brand e fondatori come esempio per raccontare storie in modo diverso