1. Gruppo di lavoratori
   - Si fermano per una pausa Diet Coke
2. Conflitto
   - Doverti lavorare tutto il giorno senza pause
3. Ostacolo alla felicità
   - Mancanza di momenti di connessione e complicità tra colleghi
4. Alleato: "Diet Coke break"
   - Offre un'occasione per spezzare la routine lavorativa
5. Conclusione
   - Lavoratori riuniti quotidianamente
      - Godersi una pausa felice
      - Appuntamento alle 11.30
6. Tema
   - Appartenenza
   - Fratellanza tra colleghi
7. Acquirente principale
   - Donne