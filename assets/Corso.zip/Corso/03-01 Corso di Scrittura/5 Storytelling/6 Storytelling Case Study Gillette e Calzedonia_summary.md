Titolo: Gillette e la Mascolinità Tossica

Paragrafo di sintesi:
La campagna pubblicitaria della Gillette ha sollevato dibattiti sulla mascolinità tossica, mettendo in discussione stereotipi di genere. La pubblicità degli anni '80 rifletteva un'idea tradizionale di maschilità, mentre quella più recente affronta temi come il consenso e la prevenzione dell'assalto sessuale.

Concetti chiave:
1. Pubblicità storica degli anni Ottanta: "Gillette, the best a man can get"
2. Nuova pubblicità: "You're looking sharp" - affronta la mascolinità tossica
3. Movimento Me Too e #TimesUp - allegazioni di molestie e abuso sessuale
4. Riconciliazione tra vecchio e nuovo archetipo pubblicitario
5. Riflessione sull'archetipo più vicino e lontano dalla realtà attuale
6. Allenamento alla narrazione attraverso cambiamenti nell'ordine degli elementi
7. Storia di Brand e fondatori come esempio per raccontare storie in modo diverso