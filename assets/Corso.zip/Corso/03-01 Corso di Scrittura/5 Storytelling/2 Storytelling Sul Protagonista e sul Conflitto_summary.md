Titolo: Il ruolo del protagonista nella costruzione di una storia

Paragrafo di sintesi:
Il protagonista è fondamentale nella struttura di una storia, poiché i bisogni e i desideri del personaggio principale mettono in moto la macchina narrativa. Senza un protagonista con esigenze da soddisfare, non ci sarebbe conflitto o motivo per l'esistenza di un brand che cerca di rispondere a quei bisogni. L'empatia verso il personaggio e il suo arco di trasformazione aiutano ad instaurare una connessione tra il pubblico e la storia, rendendo più probabile l'accettazione del messaggio del brand.

Bullet puntati:
1. Il protagonista è un individuo o un gruppo con bisogni e desideri.
2. I bisogni e i desideri del protagonista mettono in moto la macchina narrativa.
3. Senza conflitto, non c'è storia da raccontare.
4. L'empatia verso il personaggio aiuta a creare una connessione con il pubblico.
5. La connessione è fondamentale perché il pubblico scelga un brand o un'azienda.
6. L'antagonista può essere una situazione sfavorevole o un rivale.
7. Nelle storie di brand, l'antagonista può essere il bisogno insoddisfatto del cliente.