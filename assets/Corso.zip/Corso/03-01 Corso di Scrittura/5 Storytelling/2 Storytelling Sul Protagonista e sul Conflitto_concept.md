- Il protagonista è fondamentale nella struttura di una storia
  - I bisogni e i desideri del personaggio principale mettono in moto la macchina narrativa
    → Senza conflitto, non c'è storia da raccontare
      - L'antagonista può essere una situazione sfavorevole o un rivale
        * Nelle storie di brand, l'antagonista può essere il bisogno insoddisfatto del cliente
  - L'empatia verso il personaggio aiuta a creare una connessione con il pubblico
    → La connessione è fondamentale perché il pubblico scelga un brand o un'azienda
      - I bisogni e i desideri del protagonista mettono in moto la macchina narrativa
        * Il protagonista è un individuo o un gruppo con bisogni e desideri