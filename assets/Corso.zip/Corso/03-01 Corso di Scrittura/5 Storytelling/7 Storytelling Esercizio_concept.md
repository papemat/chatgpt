- Fondazione di Etsy nel 2005 da parte di tre amici
    - Espansione costante grazie al passaparola degli artisti e dei loro clienti
        → Ha portato a una notevole crescita dell'azienda
            - Cambiamenti dirigenziali con Chad Dickerson e John Silverman
                → Avervi contribuito alla gestione e allo sviluppo del business
                    - Obiettivo di impatto ecologico zero raggiunto dall'azienda
                        → Dimostrazione dell'impegno verso la sostenibilità ambientale
                            - Sostenibilità e impegno sociale nell'integrazione delle minoranze e della tutela dei lavoratori
                                → Contribuisce alla creazione di un ambiente di lavoro inclusivo
                                    - Supporto economico a milioni di artigiani e clienti nel realizzarsi professionalmente
                                        → Ha permesso l'espansione del mercato e la crescita economica per molti individui