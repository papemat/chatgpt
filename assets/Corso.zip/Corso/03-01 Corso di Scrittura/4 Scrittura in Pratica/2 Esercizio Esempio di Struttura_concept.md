1. Strutturare una pubblicità: elementi e tecniche
   → In questo esempio, l'insegnante mostra come organizzare un messaggio pubblicitario utilizzando i vari elementi della struttura
      → Partendo dal titolo fino ai benefici del prodotto
         - Includendo anche sottotitoli
         - Strutturazione del messaggio in blocchi o bullet per una lettura a cascata
         - Inclusione dei benefici del prodotto o della soluzione offerta
         - Utilizzo di testimonial per aumentare la credibilità e l'autorità del messaggio
            * L'insegnante sottolinea l'importanza di avere chiari i contenuti prima di iniziare a strutturare il messaggio pubblicitario
            * E di utilizzare correttamente tutti gli elementi per creare un efficace copy
      → Chiusura con una call to action (CTA) per incoraggiare l'azione da parte del lettore