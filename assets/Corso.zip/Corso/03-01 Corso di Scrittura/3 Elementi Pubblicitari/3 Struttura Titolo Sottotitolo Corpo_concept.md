- Il titolo è la parte più importante di qualsiasi testo
  - Cattura l'attenzione del lettore
    → Funzione principale del titolo
  - Deve essere conciso e chiaro
    → Aiuta il lettore a comprendere subito il contenuto

- Il sottotitolo (o subhead) riprende e approfondisce quanto affermato nel titolo
  - Rafforza l'argomento del titolo
    → Fornisce più dettagli sul tema trattato
  - Aiuta a strutturare il contenuto
    → Guida il lettore attraverso il testo

- Il corpo del testo spiega il contenuto del titolo e del sottotitolo
  - Dettaglia i punti chiave
    → Fornisce informazioni utili al lettore
  - Utilizza schemi come PASS per strutturare il contenuto
    → Agevola la comprensione del messaggio

- Separare i blocchi di testo ogni 3-4 righe per una migliore leggibilità
  - Facilita la lettura e l'assimilazione dell'informazione
    → Ottimizza l'esperienza del lettore

- Targettizzare il contenuto in base agli intenti di ricerca dei lettori
  - Adatta il messaggio al pubblico di riferimento
    → Incrementa la rilevanza e l'interesse per il contenuto

- Agitare un problema e proporne una soluzione per attirare l'attenzione del lettore
  - Crea interesse e curiosità
    → Spinge il lettore a voler leggere il resto del contenuto