Titolo: Scontorno di immagine su Photoshop

Paragrafo di sintesi:
In questo tutorial, vengono mostrate le tecniche per scontornare un'immagine di una ballerina utilizzando Adobe Photoshop. L'obiettivo è ottenere una figura ben delineata su uno sfondo bianco, nero o colorato. Il processo prevede l'utilizzo di strumenti come la Penna, il Secchiello e la Selezione per creare un tracciato attorno all'immagine, trasformarlo in una selezione e infine copiare la ballerina su uno sfondo nuovo.

Concetti chiave:
1. Aprire l'immagine nel documento di Photoshop
2. Creare un nuovo livello e inserire l'immagine
3. Utilizzare lo strumento Penna per tracciare il contorno dell'immagine
4. Convertire il tracciato in una selezione
5. Copiare la ballerina su uno sfondo nuovo
6. Utilizzare le opzioni di Selezione per invertire l'immagine e cancellare lo sfondo originale
7. Ritocchiare e personalizzare la ballerina e il suo sfondo finale