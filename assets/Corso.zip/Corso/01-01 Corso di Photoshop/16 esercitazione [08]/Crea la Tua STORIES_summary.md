1. Titolo: Esercitazione Stories - Grafica 2

2. Paragrafo di sintesi:
Nell'esercitazione "Stories - Grafica 2", gli studenti vengono guidati nella creazione di un'immagine ispirata a una tavola da disegno predefinita. L'obiettivo è replicare la grafica utilizzando colori e spazi diversi, includendo elementi come città in bianco, sfumature, pennellate rosse e riflessi. Gli studenti saranno incoraggiati a utilizzare strumenti come gomma e tavole di disegno per completare la grafica.

3. Bullet con i concetti chiave:
- Replicazione di una grafica predefinita su una tavola da disegno
- Utilizzo di colori e spazi diversi rispetto alla lezione precedente
- Inclusione di città in bianco, sfumature e pennellate rosse
- Aggiunta di riflessi per migliorare l'immagine finale
- Utilizzo della gomma e delle tavole di disegno come strumenti creativi
- Salvataggio del file completato in formato PSD