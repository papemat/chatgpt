Esercitazione Stories - Grafica 2
├── Creazione di un'immagine ispirata a una tavola da disegno predefinita
│   ├── Replicazione della grafica utilizzando colori e spazi diversi rispetto alla lezione precedente
│   │   └── Inclusione di elementi come città in bianco, sfumature e pennellate rosse
│   │       └── Aggiunta di riflessi per migliorare l'immagine finale
│   ├── Utilizzo della gomma e delle tavole di disegno come strumenti creativi
│   └── Salvataggio del file completato in formato PSD
└── Obiettivo: Guida degli studenti nella creazione di un'immagine ispirata a una tavola da disegno predefinita