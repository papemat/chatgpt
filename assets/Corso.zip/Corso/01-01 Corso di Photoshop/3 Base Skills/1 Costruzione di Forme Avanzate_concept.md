1. Strumenti rettangolo secondari su Photoshop
   - Lo strumento rettangolo arrotondato crea forme con angoli rotondi
     → Relazione: Tipo di forma generata
   - Lo strumento ellisse genera figure geometriche simmetriche
     → Relazione: Tipo di forma generata
   - Lo strumento poligono disegna poligoni con un numero variabile di lati
     → Relazione: Tipo di forma generata
   - Lo strumento linea crea linee rette o curve
     → Relazione: Tipo di forma generata

2. Modifiche delle proprietà
   - Opzioni di colore e spessore per personalizzare le forme
     → Relazione: Personalizzazione della forma
   - Controllo ortogonale (premere shift) per mantenere le forme parallele alle assi del foglio
     → Relazione: Modifica delle proprietà per il controllo della forma
   - Creare un nuovo livello per ogni forma per una maggiore pulizia e organizzazione
     → Relazione: Organizzazione dello spazio di lavoro

3. Sommario
   - Strumenti rettangolo secondari su Photoshop per creare diverse forme geometriche
     → Relazione: Obiettivo generale dei strumenti
   - Spiegazione delle differenze tra gli strumenti e come modificarne le proprietà
     → Relazione: Comprensione dell'utilizzo e della personalizzazione degli strumenti