- Creazione di selezioni complesse con lo strumento Lazo
  - Parola chiave: Selezione rettangolare, ellittica, libera, strumento Lazo, animazioni a pallina, trasformazioni, operatività all'interno delle forme
    - Utilizzo dello strumento Lazo per creare selezioni rettangolari, ellittiche e libere
      → Animazione a pallina durante la chiusura della selezione
        → Deselezione e creazione di nuove selezioni
          → Cambio colore e pennellate all'interno delle forme
            → Utilizzo dello strumento Gomma per operare sulla selezione
              → Selezione tramite strumento Lazo libero
                → Creazione di forme complesse utilizzando combinazioni di strumenti di selezione
                  → Trasformazioni e alterazioni delle forme, come scalatura, rotazione e inclinazione prospettica
                    → Utilizzo degli strumenti di taglio per creare dinamiche complesse
                      → Unione e fusione dei livelli tramite Command + Ctrl + E
                        → Creazione di riflessioni speculare delle forme utilizzando lo strumento Riflessione orizzontale
                          → Cambio colore delle forme anche dopo la loro realizzazione
                            → Selezione automatica su più livelli e trasformazioni con Command o Control T