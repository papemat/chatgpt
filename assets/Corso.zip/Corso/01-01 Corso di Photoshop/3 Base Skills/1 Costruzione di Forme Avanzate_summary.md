1. Strumenti rettangolo secondari su Photoshop

In questo video viene mostrato come utilizzare gli strumenti rettangolo secondari su Adobe Photoshop, tra cui lo strumento rettangolo arrotondato, ellisse, poligono e linea. Vengono spiegate le differenze tra questi strumenti e come modificarne le proprietà per ottenere forme personalizzate.

2. Paragrafo di sintesi
Lo strumento rettangolo arrotondato su Photoshop consente di creare forme con angoli rotondi, mentre lo strumento ellisse genera figure geometriche con due assi simmetrici. Lo strumento poligono permette di disegnare poligoni con un numero variabile di lati, e lo strumento linea crea linee rette o curve con diverse opzioni di colore e spessore.

3. Bullet principali:
- Strumento rettangolo arrotondato: crea forme con angoli rotondi
- Strumento ellisse: genera figure geometriche simmetriche
- Strumento poligono: disegna poligoni con un numero di lati personalizzabile
- Strumento linea: crea linee rette o curve, con opzioni di colore e spessore
- Controllo ortogonale: premere shift per mantenere le forme parallele alle assi del foglio
- Nuovo livello: creare un nuovo livello per ogni forma per una maggiore pulizia e organizzazione