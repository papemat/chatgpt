1. Importazione immagini in Photoshop
2. La lezione spiega come importare immagini all'interno di Photoshop utilizzando tre metodi diversi: drag and drop, apertura tramite clic e copia/incolla. Inoltre, viene illustrato come convertire un layer avanzato in un raster e come gestire immagini PNG con sfondo trasparente.

3. Bullet puntati:
- Drag and drop per importare immagini
- Apertura tramite clic sul mouse
- Copia/incolla per importare immagini
- Conversione di layer avanzati in raster
- Gestione di immagini PNG con sfondo trasparente
- Salvataggio del file con il comando "File" > "Salva con nome"
- Minimizzazione del file di lavoro