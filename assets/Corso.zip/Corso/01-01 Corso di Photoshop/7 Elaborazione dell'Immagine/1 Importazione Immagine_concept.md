1. Importazione immagini in Photoshop
   - Drag and drop per importare immagini →
     - Apertura tramite clic sul mouse →
       - Copia/incolla per importare immagini →
         - Conversione di layer avanzati in raster →
           - Gestione di immagini PNG con sfondo trasparente →
             - Salvataggio del file con il comando "File" > "Salva con nome" →
               - Minimizzazione del file di lavoro