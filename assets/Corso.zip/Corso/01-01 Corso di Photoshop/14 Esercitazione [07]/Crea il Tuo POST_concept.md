1. Post Quadrato sui Social Media
   2. In questo foglio di lavoro 1.1, l'esercitazione è dedicata alla creazione del "post quadrato" per i social media.
      - Introduzione al post quadrato sui social
      - Identificazione dei livelli nel post
         → Livello contenuti testuali
         → Livello media (immagini JPEG)
            • Utilizzo di immagini JPEG nel livello media
         → Livello interattività (link, hashtag, emoji)
      - Creazione di un post completo e ben strutturato
      - Importanza della qualità nell'immagine del post
      - Condivisione efficace del post sui social media