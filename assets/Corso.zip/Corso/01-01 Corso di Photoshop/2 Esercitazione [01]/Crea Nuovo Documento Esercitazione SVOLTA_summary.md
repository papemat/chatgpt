1. Creazione Documenti Quadrati e A4 in Photoshop
2. In questa lezione si impara a creare due documenti in Adobe Photoshop: uno in formato quadrato e uno in formato A4, impostando le dimensioni, il colore e aggiungendo livelli di colore.

3. Impostazioni del documento:
   - Creazione di un nuovo documento quadrato con dimensioni 200x200 mm
   - Selezione del metodo di colore RGB per il documento quadrato
   - Creazione di un nuovo documento A4 in formato CMYK

4. Aggiunta livelli di colore:
   - Creazione di tre nuovi livelli: rosso, blu e giallo
   - Bloccaggio dello sfondo e modifica dei livelli di colore

5. Rasterizzazione delle forme:
   - Creazione di forme quadrate utilizzando lo strumento "Forma"
   - Rasterizzazione delle forme per chiudere i quadrati

6. Gruppo dei livelli:
   - Aggregazione dei tre livelli di colore in un unico gruppo
   - Salvataggio del documento in formato JPEG o PDF

7. Esportazione e salvataggio:
   - Concentrarsi sui livelli come base della grafica vettoriale e raster
   - Scegliere il formato di esportazione richiesto nell'esercitazione