1. Esercitazione Photoshop: Documenti Post Quadrato e A4 Stampa

2. In questa esercitazione, si apprenderanno le basi di Adobe Photoshop lavorando su due documenti: "Post quadrato" e "A4 stampa". Si creeranno livelli sovrapposti in ciascun documento, rinominandoli e bloccandoli successivamente. Infine, si salveranno i file nel formato PSD.

3. Aprire Adobe Photoshop e creare un nuovo documento "Post quadrato" con dimensioni 200mm x 200mm e metodo di colore RGB.
* Creare tre livelli: rosso, blu e giallo
* Sovrapporre i livelli
* Rinominare e bloccare i livelli
* Salvare il file in formato PSD

4. Aprire un nuovo documento "A4 stampa" con dimensioni 210mm x 297mm e metodo di colore CMYK.
* Aggiungere tre quadrati primari: rosso, blu e giallo
* Inserire i quadrati all'interno di un gruppo chiamato "Colori Primari"
* Creare due livelli: uno con il gruppo "Colori Primari" e uno contenente i tre quadrati primari
* Rinominare e bloccare i livelli
* Salvare il file in formato PSD