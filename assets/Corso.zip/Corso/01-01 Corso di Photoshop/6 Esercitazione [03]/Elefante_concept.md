Creazione di forme circolari su foglio quadrato
├── Creazione di diverse forme circolari
│   ├── Utilizzo di strumenti come nuvole e tracciati
│   └── Generare un'unica immagine che combina tutte le forme create
└── Concetti chiave
    ├── Creazione di un foglio quadrato
    ├── Utilizzo dello strumento colore RGB
    ├── Aggiunta di tracciati e nuvole al progetto
    │   └── Forme circolari dominate da segmentazioni e spezzature della linea
    ├── Tipi di nuvola:
    │   ├── Nuvola sfumata
    │   ├── Nuvola intera
    │   └── Nuvola traccia su tracciato
    └── Salvataggio del file in formato PSD e JPEG