1. Creazione di forme circolari su foglio quadrato

2. In questa esercitazione, gli studenti vengono guidati attraverso il processo di creazione di diverse forme circolari utilizzando strumenti come nuvole e tracciati. L'obiettivo è di generare un'unica immagine che combina tutte le forme create.

3. Concetti chiave:
   - Creazione di un foglio quadrato
   - Utilizzo dello strumento colore RGB
   - Aggiunta di tracciati e nuvole al progetto
   - Forme circolari dominate da segmentazioni e spezzature della linea
   - Nuvola sfumata, intera e traccia su tracciato
   - Salvataggio del file in formato PSD e JPEG