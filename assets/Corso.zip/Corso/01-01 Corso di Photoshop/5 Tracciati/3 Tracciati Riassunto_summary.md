1. Rivedere tracciati rettangolari, squadrati e curvi
2. Lezione ripercorre velocemente lo strumento penna e i suoi sottogruppi, senza spiegare ogni passaggio.
3. Mantenere la pressione per fare curve o chiudere il tracciato
4. Usare CTRL e barra spaziatrice per avvicinarsi a punti
5. Premere A e cliccare per spezzare maniglie e creare spigoli
6. Cambiare icona con cambio icona a beccuccio
7. Tracciati sono svincolati dai non, ma possono essere modificati in un secondo momento
8. Usare strumento cambio punto di ancoraggio per muovere punti di ancoraggio
9. Aggiungere o eliminare punti di ancoraggio con attenzione
10. Creare selezioni e campiture per tratte geometriche e spezzate