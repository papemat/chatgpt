L'uso dello strumento Penna in Photoshop

- Lo strumento Penna in Photoshop
  - Permette di creare tracciati con punti di controllo
    → Manipolazione dei punti di controllo
      - Cambiare la forma del tracciato
- Indipendenza dei tracciati dai livelli
  - Possono essere spostati, modificati o cancellati senza influenzare altri elementi nel documento
- Opzioni di scalatura, rotazione e distorsione per trasformare i tracciati
  → Scalatura
  → Rotazione
  → Distorsione
- Conversione dei tracciati in maschere vettoriali e selezioni
  → Maschere vettoriali
  → Selezioni
- Applicazione delle trasformazioni a una campitura o un sottobanco
  → Trasformazioni applicate ai tracciati creando effetti di campitura o sottobanco