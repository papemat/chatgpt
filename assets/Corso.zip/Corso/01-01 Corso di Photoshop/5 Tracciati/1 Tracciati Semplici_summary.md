Titolo: L'uso dello strumento Penna in Photoshop

Paragrafo di sintesi:
Nella lezione di oggi, si esplora lo strumento Penna in Photoshop. Questo strumento permette di creare tracciati con punti di controllo che possono essere manipolati per cambiare la forma del tracciato stesso. I tracciati sono indipendenti dai livelli e possono essere spostati, modificati o cancellati senza influenzare altri elementi nel documento. Inoltre, si esaminano le opzioni di scalatura, rotazione e distorsione per trasformare i tracciati.

Concetti chiave:
1. Selezione dello strumento Penna
2. Creazione di tracciati con punti di controllo
3. Manipolazione dei punti di controllo per modificare il tracciato
4. Indipendenza dei tracciati dai livelli
5. Scalatura, rotazione e distorsione dei tracciati
6. Conversione dei tracciati in maschere vettoriali e selezioni
7. Applicazione delle trasformazioni a una campitura o un sottobanco