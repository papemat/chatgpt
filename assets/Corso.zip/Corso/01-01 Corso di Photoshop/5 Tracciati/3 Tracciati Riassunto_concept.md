Rivedere tracciati rettangolari, squadrati e curvi
  → Lezione ripercorre velocemente lo strumento penna e i suoi sottogruppi, senza spiegare ogni passaggio.
    → Mantenere la pressione per fare curve o chiudere il tracciato
      → Usare CTRL e barra spaziatrice per avvicinarsi a punti
        → Premere A e cliccare per spezzare maniglie e creare spigoli
          → Cambiare icona con cambio icona a beccuccio
            → Tracciati sono svincolati dai non, ma possono essere modificati in un secondo momento
              → Usare strumento cambio punto di ancoraggio per muovere punti di ancoraggio
                → Aggiungere o eliminare punti di ancoraggio con attenzione
                  → Creare selezioni e campiture per tratte geometriche e spezzate