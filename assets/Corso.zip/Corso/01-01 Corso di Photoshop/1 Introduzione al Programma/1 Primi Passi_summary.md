1. Introduzione all'interfaccia di Photoshop

2. In questo capitolo, verranno presentate le principali funzionalità e i concetti chiave dell'interfaccia di Adobe Photoshop, il programma di grafica raster più popolare al mondo.

3. Concetti chiave:
   - Caricamento e apertura del programma
   - Creazione di un nuovo documento
   - Impostazioni del foglio di lavoro (dimensioni, orientamento, risoluzione)
   - Struttura dell'interfaccia di Photoshop
      - Menu principali: File, Immagine, Livello, Testo, Strumenti, Selezione, Filtri, 3D, Visualizzazione, Aiuto
      - Barra degli strumenti e selezione degli strumenti
      - Tavola di disegno e livelli
   - Panoramica sugli strumenti disponibili (pennello, selettore, sposta, ecc.)
4. L'obiettivo principale è fornire una panoramica dell'interfaccia di Photoshop, in modo che gli utenti possano comprendere la struttura del programma e trovare più facilmente le funzionalità necessarie per i loro progetti grafici.