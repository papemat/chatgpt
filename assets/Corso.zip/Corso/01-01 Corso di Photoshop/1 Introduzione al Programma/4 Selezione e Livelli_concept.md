Lo Strumento Selezione in Photoshop
    È contraddistinto dalla lettera M come shortcut da tastiera
        → Il cursore si trasforma in un crociato
            → Per delineare aree tratteggiate
            → E selezionare forme all'interno della tavola da disegno
    È possibile effettuare deselezioni utilizzando il shortcut Command o Control D
        → Questo permette di cancellare una selezione precedentemente fatta
    Consente di personalizzare l'area contenuta all'interno della selezione
        → Permettendo di applicare colori o riempimenti solo su tale area
            → Questo rende lo strumento molto versatile e potente
    Esistono diverse forme dello strumento selezione, come rettangolare e ellittica
        → Queste forme possono essere utilizzate per creare selezioni più precise
    Le selezioni possono essere fuse per creare risultati complessi
        → Questa funzionalità aggiunge un'altra dimensione di personalizzazione
            → Consentendo l'uso di combinazioni creative di forme e colori