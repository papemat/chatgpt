1. Utilizzo degli strumenti rettangolo, ellisse, linea e forma personale in Photoshop per creare forme geometriche.
2. In questa lezione si è imparato a utilizzare gli strumenti di base di Photoshop per disegnare e manipolare forme geometriche su diversi livelli.

- Selezionare lo strumento rettangolo (U) e crearne uno sulla tavola di disegno.
- Utilizzare il rettangolo arrotondato, l'ellisse, la linea e la forma personale per creare diverse forme geometriche.
- Creare gruppi temporanei di forme utilizzando lo strumento sposta con selezione automatica.
- Unire i livelli in un unico gruppo o fuserli insieme.
- Copiare e incollare forme su nuovi livelli per creare composizioni più complesse.