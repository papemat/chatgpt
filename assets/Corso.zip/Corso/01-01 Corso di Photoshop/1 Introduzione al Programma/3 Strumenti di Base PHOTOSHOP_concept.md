1. Introduzione ai principali strumenti di Photoshop

    2. Paragrafo di sintesi:
        → Lo strumento Sposta
        → La Selezione rettangolare
        → L'uso della Bacchetta Magica
        → Lo strumento Lazo Poligonale
        → Lo strumento Contagocce

3. Bullet con i concetti chiave in ordine cronologico:
    - Introduzione ai primi strumenti di base di Adobe Photoshop
        → Lo strumento Sposta (V): spostamento di oggetti su nuovi livelli
        → La Selezione rettangolare: creazione di selezioni rettangolari o ellittiche, con opzione per forme geometriche controllate utilizzando il tasto Shift
        → L'uso della Bacchetta Magica: selezionare campiture e forme, sia in modalità additiva che sottrattiva
            → Lo strumento Lazo Poligonale (L): creazione di selezioni geometriche o libere
                → Lo strumento Contagocce (I): estrazione di colori da un'immagine e applicazione su una tavolozza
                    → Bloccaggio delle proprietà sui livelli per l'utilizzo dello strumento Contagocce
                        → Uso del pennello per modificare le selezioni e personalizzare il lavoro in Photoshop