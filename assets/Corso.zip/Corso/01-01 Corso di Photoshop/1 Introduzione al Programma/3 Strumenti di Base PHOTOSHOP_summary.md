1. Introduzione ai principali strumenti di Photoshop
2. Paragrafo di sintesi:
In questo capitolo, vengono presentati i primi strumenti di base di Adobe Photoshop, che sono essenziali per iniziare a lavorare con il software. Vengono illustrati lo strumento Sposta, la Selezione rettangolare e l'uso della Bacchetta Magica. Inoltre, viene mostrato come utilizzare la Bacchetta Magica per selezionare campiture e forme, e come creare selezioni geometriche o libere utilizzando il Lazo Poligonale. Infine, viene presentato lo strumento Contagocce, che consente di estrarre colori da un'immagine e applicarli su una tavolozza.
3. Bullet con i concetti chiave in ordine cronologico:
- Introduzione ai primi strumenti di base di Adobe Photoshop
- Lo strumento Sposta (V): spostamento di oggetti su nuovi livelli
- La Selezione rettangolare: creazione di selezioni rettangolari o ellittiche, con opzione per forme geometriche controllate utilizzando il tasto Shift
- L'uso della Bacchetta Magica: selezionare campiture e forme, sia in modalità additiva che sottrattiva
- Lo strumento Lazo Poligonale (L): creazione di selezioni geometriche o libere
- Lo strumento Contagocce (I): estrazione di colori da un'immagine e applicazione su una tavolozza
- Bloccaggio delle proprietà sui livelli per l'utilizzo dello strumento Contagocce
- Uso del pennello per modificare le selezioni e personalizzare il lavoro in Photoshop