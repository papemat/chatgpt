Introduzione all'interfaccia di Photoshop
    → Concetti chiave
        - Caricamento e apertura del programma
            → Impostazioni del foglio di lavoro (dimensioni, orientamento, risoluzione)
                → Struttura dell'interfaccia di Photoshop
                    - Menu principali: File, Immagine, Livello, Testo, Strumenti, Selezione, Filtri, 3D, Visualizzazione, Aiuto
                        → Barra degli strumenti e selezione degli strumenti
                            → Tavola di disegno e livelli
                    → Panoramica sugli strumenti disponibili (pennello, selettore, sposta, ecc.)