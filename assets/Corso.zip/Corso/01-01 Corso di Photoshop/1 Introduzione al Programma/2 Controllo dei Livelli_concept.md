Introduzione ai Livelli in Photoshop
    → Visibilità e bloccaggio dei livelli
        → Trasparenza dei livelli
            → Ordinamento e gestione dei livelli
                → Duplicazione di un livello per lavorare su copie separate
                    → Utilizzo di strumenti come il secchiello per colorare i livelli
                        → Salvataggio di file con sfondi trasparenti (PNG o JPEG)