1. Scontorno tramite tracciato
    2. Esercitazione dedicata allo scontorno tramite tracciato
        - Accensione dell'esercitazione
        - Visualizzazione dell'immagine con sfondo nero
        - Seguimento dei passi visti nella lezione precedente
        - Ricerca dello sdoppiamento simmetrico perfetto
            → Lo scopo è quello di raggiungere uno sdoppiamento simmetrico perfetto, in simbiosi con la foto originaria.
        - Selezione sulla base dello spawn e cancellazione del livello scontornato
        - Disattivazione della funzione di esercitazione
            → L'immagine scelta ha uno sfondo nero per evidenziare i contrasti.
        - Augurio di buon lavoro ai partecipanti