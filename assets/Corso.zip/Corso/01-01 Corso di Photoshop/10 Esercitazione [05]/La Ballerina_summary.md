1. Scontorno tramite tracciato con penna
2. Nell'esercitazione dedicata allo scontorno tramite tracciato, lo speaker guida i partecipanti attraverso i passi necessari per ottenere un risultato di alta qualità. L'immagine scelta ha uno sfondo nero per evidenziare i contrasti. Lo scopo è quello di raggiungere uno sdoppiamento simmetrico perfetto, in simbiosi con la foto originaria.
3. - Accensione dell'esercitazione
- Visualizzazione dell'immagine con sfondo nero
- Seguimento dei passi visti nella lezione precedente
- Ricerca dello sdoppiamento simmetrico perfetto
- Selezione sulla base dello spawn e cancellazione del livello scontornato
- Disattivazione della funzione di esercitazione
- Augurio di buon lavoro ai partecipanti