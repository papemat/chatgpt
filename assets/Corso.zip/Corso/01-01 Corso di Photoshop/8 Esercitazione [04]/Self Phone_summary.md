1. Editing geometrico di immagini in Photoshop

2. Nell'esercitazione, gli studenti devono applicare le tecniche di editing geometrico apprese a lezione per modificare immagini e foto all'interno del file di Photoshop. L'obiettivo è copiare forme e elementi presenti nelle immagini fornite.

3. Gli strumenti utilizzati includono:
- Lazo: selezionare precise aree delle immagini
- Pennelli: colorare le aree selezionate
- Strumento tasto rotondo: applicare effetti circolari alle immagini
- Rettangolo: tracciare forme rettangolari e inclinarle utilizzando lo strumento "occhio"
- Selezione di livello: isolare e tagliare elementi delle immagini

4. Gli studenti devono:
1. Aprire il gruppo contenente tutti i media relativi all'esercizio
2. Utilizzare il cellulare fornito come riferimento per le tecniche di editing geometrico
3. Modificare la foto della ragazza sull'altarietta applicando effetti circolari utilizzando lo strumento tasto rotondo
4. Creare una banda rossa rettangolare con inclinazione, tracciandola e inclinandola utilizzando lo strumento "occhio"
5. Intagliare un'immagine nera all'interno di una banda, copiando l'immagine originale e ingrandendola
6. Isolare, opacizzare e inserire l'immagine copiata sulla preconfezionata

5. L'esercitazione mira a consolidare la padronanza degli strumenti di editing geometrico in Photoshop e ad applicarli per creare comunicazioni pubblicitarie o effetti visivi simili a quelli visti a lezione.