Fissaggio e selezione di strumenti: esercitazione con lo strumento rettangolo e forma

1. Utilizzo dello strumento rettangolo per disegnare forme → Creazione di nuovi livelli per ogni oggetto
2. Trasformazione delle forme con gli strumenti di alterazione fotografica
   → Suddivisione del disegno in sottogruppi e sottoggetti
3. Unione dei livelli in un gruppo
4. Prendere dimestichezza con il nome dei livelli e la loro gestione
   → Apprezzamento del risultato finale nella tavola di disegno