Titolo:
Fissaggio e selezione di strumenti: esercitazione con lo strumento rettangolo e forma

Paragrafo di sintesi:
Nell'esercitazione, l'obiettivo è il fissaggio di quanto appreso sugli strumenti di selezione e forma, in particolare utilizzando lo strumento rettangolo. Vengono presentati i concetti chiave come la creazione di nuovi livelli, la trasformazione delle forme con gli strumenti di alterazione fotografica, la suddivisione del disegno in sottogruppi e sottoggetti, e l'unione dei livelli in un gruppo. L'esercitazione mira a consolidare le competenze acquisite sugli strumenti di selezione e forma.

Concetti chiave:
1. Utilizzo dello strumento rettangolo per disegnare forme
2. Creazione di nuovi livelli per ogni oggetto
3. Trasformazione delle forme con gli strumenti di alterazione fotografica
4. Suddivisione del disegno in sottogruppi e sottoggetti
5. Unione dei livelli in un gruppo
6. Prendere dimestichezza con il nome dei livelli e la loro gestione
7. Apprezzamento del risultato finale nella tavola di disegno