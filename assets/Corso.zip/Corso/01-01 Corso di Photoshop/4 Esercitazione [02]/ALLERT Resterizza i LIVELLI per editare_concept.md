1. Lavorare con forme non rasterizzate
   - Generano messaggi di errore durante l'editing
     → Forme non rasterizzate
2. Rasterizzazione di forme
   - Per evitare errori comuni
     → Evitare errori comuni lavorando con forme in Photoshop
3. Metodi per rasterizzare una forma
   1) Selezionare la forma
      → Rasterizzazione di forme
   2) Usare il comando "Control" + "R"
      → Rasterizzazione di forme
   3) Utilizzare l'opzione "Operazione dinamica"
      → Rasterizzazione di forme