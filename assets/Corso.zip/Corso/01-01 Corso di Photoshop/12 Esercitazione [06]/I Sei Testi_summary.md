Titolo: Esercitazione sui Testi Rasterizzati

Paragrafo di sintesi:
Nell'esercitazione, vengono presentati sei esercizi focalizzati sulla manipolazione e l'interazione tra testo rasterizzato e immagine. Gli studenti saranno guidati attraverso la modifica di forme, il riflettore, il cancellare, l'utilizzo di sfondi e ombre per creare effetti visivi interessanti. L'esercizio si concentra su aspetti come opacità dei livelli, selezione di tracciati e l'importanza di salvare copie dei propri testi.

Concetti chiave:
1. Testo rasterizzato
2. Forme e sfondi
3. Riflessi e opacità dei livelli
4. Selezione tramite tracciato
5. Ombre e fusione
6. Utilizzo di texture per creare effetti visivi
7. Importanza di salvare copie dei testi
8. Creazione di interazioni tra testo ed immagine
9. Esecuzione di operazioni come copia, incolla e modifica
10. Salvataggio del lavoro in formato JPEG