Esercitazione sui Testi Rasterizzati

- Manipolazione e interazione tra testo rasterizzato e immagine
  - Modifica di forme
    → Forme e sfondi
  - Utilizzo di riflettore, cancellare, sfondi e ombre
    → Riflessi e opacità dei livelli
    → Ombre e fusione
    → Creazione di interazioni tra testo ed immagine
  - Gestione delle opacità dei livelli
    → Opacità dei livelli
- Selezione tramite tracciato
  → Selezione tramite tracciato
- Importanza di salvare copie dei propri testi
  → Importanza di salvare copie dei testi
- Esecuzione di operazioni come copia, incolla e modifica
  → Utilizzo di texture per creare effetti visivi
  → Creazione di interazioni tra testo ed immagine
- Salvataggio del lavoro in formato JPEG
  → Importanza di salvare copie dei testi