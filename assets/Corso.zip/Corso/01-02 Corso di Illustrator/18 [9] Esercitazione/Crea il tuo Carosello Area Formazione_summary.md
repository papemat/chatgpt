1. Creazione carosello step by step
2. L'esercitazione di oggi è un foglio di lavoro particolare in cui ci si eserciterà sul carosello. L'obiettivo è quello di andare a ricreare tutti i passaggi che abbiamo visto insieme nella lezione appunto denominata "carosello". Saranno presenti 4 tavole di lavoro, ma si può aumentare il numero se ritenuto necessario.

3. Mimetizzare i passaggi visti nella lezione
- Creazione grafica
- Aggiunta testo e campiture
- Editing del testo
- Merging di immagini
- Aggiunta logo/personalizzazione
4. Utilizzo dei media e file scaricabili correlati all'esercitazione
5. Ripasso globale del software, che include: grafica, testi sui tracciati, editing di testo e merging di immagini.