Creazione carosello step by step
├── Esercitazione particolare sul carosello
│   ├── Obiettivo: ricreare i passaggi visti nella lezione "carosello"
│   └── 4 tavole di lavoro, incrementabili se necessario
└── Mimetizzazione dei passaggi visti nella lezione
    ├── Creazione grafica
    ├── Aggiunta testo e campiture
    ├── Editing del testo
    └── Merging di immagini
        └── Aggiunta logo/personalizzazione
            → Utilizzo dei media e file scaricabili correlati all'esercitazione
                → Ripasso globale del software
                    ├── Grafica
                    ├── Testi sui tracciati
                    ├── Editing di testo
                    └── Merging di immagini