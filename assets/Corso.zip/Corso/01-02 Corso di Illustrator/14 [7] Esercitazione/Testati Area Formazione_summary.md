1. Esercitazione su Testati: Conversione Testo in Tracciato

2. In questo esercizio, gli studenti vengono guidati attraverso la conversione del testo in tracciato utilizzando Adobe Illustrator. Vengono presentati cinque mini-esercizi che illustrano diversi aspetti della conversione, come il riempimento delle lettere, l'editing dei punti di contatto e l'inserimento di testo su tracciato all'interno di forme colorate.

3. Bullet punti chiave:
   - Conversione del testo in tracciato
   - Riempimento delle lettere
   - Editing dei punti di contatto
   - Abbassamento dell'opacità
   - Inserimento di testo su tracciato all'interno di forme colorate
   - Formato finale: .ai (Adobe Illustrator)