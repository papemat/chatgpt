1. Editing immagini: Esercitazione Franco Bolli

2. In questa esercitazione, gli studenti saranno guidati attraverso il processo di editing di tre immagini che rappresentano francobolli. Ogni francobollo presenta sfide diverse in termini di ritaglio, creazione di ombre e applicazione di effetti di stile. Gli studenti impareranno a utilizzare strumenti di ritaglio come cerchi, forme geometriche e tratteggi per ricavare le immagini desiderate, applicare ombre interne ed esterne e utilizzare gli effetti di sfumatura e sfocatura per creare atmosfera. L'esercitazione si conclude con la salvaguardia del lavoro in formato JPEG e PDF, pronto per la stampa.

3. Bullet punti:
   - Utilizzo di strumenti di ritaglio come cerchi, forme geometriche e tratteggi
   - Creazione di ombre interne ed esterne utilizzando gli effetti di stilizzazione
   - Applicazione di effetti di sfumatura e sfocatura per aggiungere atmosfera
   - Raggruppamento e separazione di elementi per una gestione più efficiente del progetto
   - Bloccaggio e sbloccaggio di strumenti per modifiche precise
   - Salvataggio del lavoro in formato JPEG e PDF, pronto per la stampa