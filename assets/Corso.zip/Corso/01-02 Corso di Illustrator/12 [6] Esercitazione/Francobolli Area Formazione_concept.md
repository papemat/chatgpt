Editing immagini: Esercitazione Franco Bolli

- Utilizzo di strumenti di ritaglio come cerchi, forme geometriche e tratteggi
  → Ritaglio delle immagini dei francobolli
    - Cerchi
    - Forme geometriche
    - Tratteggio

- Creazione di ombre interne ed esterne utilizzando gli effetti di stilizzazione
  → Ombreggianti per dare profondità
    - Ombre interne
    - Ombre esterne
    - Effetti di stilizzazione

- Applicazione di effetti di sfumatura e sfocatura per aggiungere atmosfera
  → Aggiunta di effetti per creare un'atmosfera
    - Effetti di sfumatura
    - Effetti di sfocatura

- Raggruppamento e separazione di elementi per una gestione più efficiente del progetto
  → Organizzazione del lavoro
    - Raggruppamento di elementi
    - Separazione di elementi

- Bloccaggio e sbloccaggio di strumenti per modifiche precise
  → Facilità nell'eseguire modifiche
    - Bloccaggio di strumenti
    - Sblocaggio di strumenti

- Salvataggio del lavoro in formato JPEG e PDF, pronto per la stampa
  → Conclusione dell'esercitazione
    - Formato JPEG
    - Formato PDF
    - Pronto per la stampa