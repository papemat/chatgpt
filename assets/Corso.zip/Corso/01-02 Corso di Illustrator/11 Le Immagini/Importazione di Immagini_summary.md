1. Importazione immagini in Adobe Illustrator
2. In questa lezione si impara a importare e scalare immagini nel programma Adobe Illustrator utilizzando Pexels come fonte di immagini gratuite.

3. Aprire Adobe Illustrator e Google Chrome
4. Ricerca di immagini su Pexels
5. Scegliere e scaricare immagini senza diritti d'autore
6. Creare una cartella per organizzare le immagini importate
7. Trascinare le immagini nella cartella e rinominarle
8. Aprire la cartella di immagini all'interno di Illustrator
9. Scalare le immagini mantenendo le proporzioni originali
10. Aggiungere le immagini come livelli nel file di lavoro
11. Utilizzare il comando "Inserisci" per importare immagini specifiche
12. Organizzare e minimizzare i file per un flusso di lavoro efficiente