1. Forme Semplici con Strumento Rettangolo in Adobe Illustrator
   - In questa lezione, si imparerà a creare forme semplici utilizzando lo strumento rettangolo in Adobe Illustrator.
     → Utilizzo dei sottogruppi all'interno dello strumento rettangolo
     → Impostazione del colore di riempimento e tracciato
     → Creazione di forme rettangolari, quadrati, ellissi e cerchi utilizzando il tasto Shift per mantenere proporzioni
       → Utilizzo della selezione diretta per modificare singoli punti delle forme
       → Togliere il colore dal riempimento o dal perimetro delle forme
     → Creazione di poligoni con numero di lati desiderato utilizzando lo strumento Poligono

2. Concetti chiave:
   - Selezione dello strumento rettangolo tramite shortcut da tastiera (m)
     → Utilizzo dei sottogruppi all'interno dello strumento rettangolo
     → Impostazione del colore di riempimento e tracciato
     → Creazione di forme rettangolari, quadrati, ellissi e cerchi utilizzando il tasto Shift per mantenere proporzioni
       → Utilizzo della selezione diretta per modificare singoli punti delle forme
       → Togliere il colore dal riempimento o dal perimetro delle forme
     → Creazione di poligoni con numero di lati desiderato utilizzando lo strumento Poligono