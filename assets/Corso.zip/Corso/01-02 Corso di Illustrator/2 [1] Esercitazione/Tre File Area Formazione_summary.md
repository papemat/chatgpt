1. Creazione di Tavole di Disegno
2. La lezione si concentra sulla creazione di tre tipi di file: due fogli A4 per stampa, un post quadrato per i social network e un foglio A4 orizzontale per condivisione web.
3. Utilizzare File Nuovo in Adobe Illustrator per creare i tre file
4. Salvare i file in formato Adobe Illustrator (AI) per consentire modifiche future
5. Mantenere il nome del file quando si salva, selezionando tutte le strutture e disegni nel processo di salvataggio
6. Non spuntare mai "Usa tavole di..." durante la salvatura
7. Chiudere il programma Adobe Illustrator con l'icona in formato AI per completare con successo l'esercitazione