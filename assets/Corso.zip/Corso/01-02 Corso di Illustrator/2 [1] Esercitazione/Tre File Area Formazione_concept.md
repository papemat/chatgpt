Creazione di Tavole di Disegno
└→ La lezione si concentra sulla creazione di tre tipi di file: due fogli A4 per stampa, un post quadrato per i social network e un foglio A4 orizzontale per condivisione web.
   └→ Utilizzare File Nuovo in Adobe Illustrator per creare i tre file
   └→ Salvare i file in formato Adobe Illustrator (AI) per consentire modifiche future
      └→ Mantenere il nome del file quando si salva, selezionando tutte le strutture e disegni nel processo di salvatatura
      └→ Non spuntare mai "Usa tavole di..." durante la salvatura
└→ Chiudere il programma Adobe Illustrator con l'icona in formato AI per completare con successo l'esercitazione