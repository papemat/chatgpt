Titolo: Forme avanzate

Paragrafo di sintesi:
In questa esercitazione vengono presentate tecniche avanzate per creare forme complesse utilizzando Adobe Illustrator. Gli studenti impareranno a generare forme tramite la simmetria, l'uso di strumenti di distanza e smussatura, e l'applicazione di curve e triangoli. L'esercitazione si concentra su sei insiemi di forme diverse, ognuna delle quali richiede l'utilizzo di tecniche specifiche per la creazione.

Concetti chiave in ordine cronologico:
1. Apertura del file in formato CMYK
2. Creazione di una forma rettangolare e taglio con strumento di selezione diretta
3. Utilizzo della simmetria per creare forme bilaterali
4. Aggiunta di smussature utilizzando lo strumento di controllo per la smussatura
5. Creazione di forme complesse attraverso l'uso di curve e triangoli
6. Salvataggio del file in formato PDF per stampa
7. Installazione del file PDF sul desktop