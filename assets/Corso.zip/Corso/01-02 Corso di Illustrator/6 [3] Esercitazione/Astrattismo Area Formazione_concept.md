1. Apertura del file in formato CMYK
   2. Creazione di una forma rettangolare e taglio con strumento di selezione diretta
      - Utilizzo della simmetria per creare forme bilaterali
         * Aggiunta di smussature utilizzando lo strumento di controllo per la smussatura
            ** Creazione di forme complesse attraverso l'uso di curve e triangoli
   3. Salvataggio del file in formato PDF per stampa
      - Installazione del file PDF sul desktop