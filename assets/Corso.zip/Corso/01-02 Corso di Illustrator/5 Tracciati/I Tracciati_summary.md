1. Tracciati in Adobe Illustrator: creazione e modifica

In questa lezione, abbiamo esplorato come utilizzare lo strumento Pen in Adobe Illustrator per creare tracciati personalizzati. Abbiamo imparato a:

- Utilizzare lo strumento Pen per disegnare tracciati liberi
- Chiudere i tracciati per creare forme chiuse
- Aprire i tracciati per lasciare una linea di riempimento
- Separare i tracciati dalle forme create
- Modificare lo spessore e il colore delle tracce
- Scalare, ruotare e deformare i tracciati
- Invertire la campitura dei tracciati

Questi concetti sono fondamentali per creare loghi, grafica vettoriale e disegni complessi in Adobe Illustrator. Esercitati con questi strumenti per migliorare le tue abilità di disegno vettoriale.