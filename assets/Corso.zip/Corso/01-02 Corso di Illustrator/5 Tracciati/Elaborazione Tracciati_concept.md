1. Creazione di forme geometriche con lo strumento rettangolo
   - Quadrati
   - Cerchi

2. Editing geometrico per interfacciare le forme
   → Interfaccia tra quadrati e cerchi

3. Raggruppamento delle forme per organizzazione

4. Elaborazione tracciati: unione, creazione di nuove forme composte e taglio
   - Unione dei tracciati
   - Creazione di nuove forme composte
   - Taglio tra i tracciati selezionati

5. Utilizzo delle proprietà per modificare colori e campiture

6. Separazione delle forme raggruppate per ottenere risultati più flessibili