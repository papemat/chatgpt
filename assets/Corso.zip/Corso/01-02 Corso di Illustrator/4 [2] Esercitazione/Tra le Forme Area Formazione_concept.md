1. Creazione di forme geometriche con Illustrator
   - File finale Adobe Illustrator
     → Utilizzato per creare figure geometriche
   - Quattro livelli verticali in colore RGB
     → Intitolato "forme"
       → Organizzazione dei contenuti

2. Livello 1: Forme base
   - Quadrato
     → Diversi opzioni di riempimento e traccia
   - Rettangolo
     → Diversi opzioni di riempimento e traccia
   - Cerchio
     → Diversi opzioni di riempimento e traccia
   - Ellisse
     → Diversi opzioni di riempimento e traccia

3. Livello 2: Geometrie complesse
   - Strumento poligono utilizzato
     → Creazione di forme geometriche più complesse
       → Esagono
       → Otaggono
       → Dodecaedro

4. Organizzazione dei livelli in gruppi
   - Square
   - Circle
   - Geometries
   - Foundation

5. Salvataggio del file
   - Estensione .ai per mantenere la modificaabilità vettoriale