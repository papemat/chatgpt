1. Creazione di forme geometriche con Illustrator

In questo esercizio, si lavora all'interno di un file finale Adobe Illustrator per creare figure geometriche utilizzando lo strumento rettangolo e i suoi sottogruppi. Il file è composto da quattro livelli verticali in colore RGB, intitolato "forme". All'interno del primo livello, sono presenti un quadrato, un rettangolo, un cerchio e una ellisse, ognuno con diverse opzioni di riempimento e traccia. Nel secondo livello, vengono create geometrie più complesse utilizzando lo strumento poligono, come esagono, ottagono e dodecaedro. Lo scopo è di organizzare i livelli in quattro gruppi: square, circle, geometries e foundation. Una volta completato il lavoro, si può salvare il file con estensione .ai per mantenere la modificaabilità vettoriale.

3. Concetti chiave:
- Strumento rettangolo e sottogruppi
- Forme geometriche: quadrato, rettangolo, cerchio, ellisse
- Strumento poligono per geometrie complesse (esagono, ottagono, dodecaedro)
- Organizzazione dei livelli in gruppi
- Salvataggio del file come .ai per mantenere la modificaabilità vettoriale