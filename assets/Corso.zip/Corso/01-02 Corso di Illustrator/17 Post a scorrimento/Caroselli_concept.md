- Caratteristiche dei caroselli Instagram
  - Composti da più immagini quadrate
  - Scorrono in un'unica pubblicazione
  - Ogni immagine ha senso autonomo ma contribuisce al messaggio globale

- Utilizzo di Adobe Illustrator
  - Creare, modificare e combinare immagini
  - Realizzare caroselli dinamici e coinvolgenti

- Creazione di un'unica grande immagine
  - Progettazione della grafica del carosello
    - Aggiunta di logo e elementi personalizzati
    - Creazione di freccette stilizzate per il swipe
    - Inserimento del nome profilo e testo

- Gestione degli elementi in layer separati
  - Allineamento e centratura degli elementi
    - Utilizzo di strumenti Illustrator per design personalizzato
      - Vettorializzazione delle immagini
        - Salvataggio e esportazione del file per la pubblicazione sui social media