Rainstorm - Esercitazione Digital Painting
├── Aprire un foglio con metodo CMYK e proporzione vicina ai 16 noni
│   └── Struttura dell'acqua: rettangoli e tracciati più complessi
└── Identificare le principali forme: acqua, barca, pescatori, luna, squalo
    ├── Utilizzare strumenti di forma per creare figure come barca, pescatori, luna e pinna dello squalo
    └── Lavorare in monocromo con un solo colore (CMYK)
        └── Prendersi tempo per studiare i percorsi più efficaci verso il risultato finale