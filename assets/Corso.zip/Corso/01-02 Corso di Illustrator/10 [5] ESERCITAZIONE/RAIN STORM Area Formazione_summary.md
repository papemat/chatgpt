1. Titolo: Rainstorm - Esercitazione Digital Painting

2. Paragrafo di sintesi:
Nell'esercitazione "Rainstorm" si lavora sulla riproduzione digitale di un digital painting che rappresenta una scena marina con temporale e squalo. L'obiettivo è utilizzare il metodo CMYK, una proporzione vicina ai 16 noni e concentrarsi sulle forme in monocromo. Si suggerisce di partire dalla struttura dell'acqua, composta da rettangoli e tracciati più complessi, per poi procedere con le altre figure presenti nella scena.

3. Bullet point:
- Aprire un foglio con metodo CMYK e proporzione vicina ai 16 noni
- Identificare le principali forme: acqua, barca, pescatori, luna, squalo
- Struttura dell'acqua: rettangoli e tracciati più complessi
- Utilizzare strumenti di forma per creare figure come barca, pescatori, luna e pinna dello squalo
- Lavorare in monocromo con un solo colore (CMYK)
- Prendersi tempo per studiare i percorsi più efficaci verso il risultato finale