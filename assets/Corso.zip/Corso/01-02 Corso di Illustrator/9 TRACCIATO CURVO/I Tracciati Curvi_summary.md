1. Tracciati Curvi: Creazione e Modifica con Adobe Illustrator

2. In questa lezione si è imparato a creare e modificare tracciati curvi utilizzando Adobe Illustrator. Si è iniziato con un ripasso sui tracciati lineari, per poi passare all'introduzione dei tracciati curvi utilizzando lo strumento "Maniglia". Con l'uso di questa tecnica, si può creare una varietà di forme curve e complesse. Si è anche esplorato come modificare i punti di controllo per cambiare la forma delle curve e come spezzare le curve per creare angoli retti o spigoli. Infine, si è discusso su come invertire i tracciati, aggiungere riempimento e migliorare ulteriormente le geometrie utilizzando strumenti di selezione diretta e trasformazione.

3. Concetti chiave:
   - Creazione di tracciati curvi con lo strumento "Maniglia"
   - Modifica dei punti di controllo per cambiare la forma delle curve
   - Spezzatura delle curve per creare angoli retti o spigoli
   - Inversione dei tracciati e aggiunta del riempimento
   - Utilizzo degli strumenti di selezione diretta e trasformazione per migliorare le geometrie