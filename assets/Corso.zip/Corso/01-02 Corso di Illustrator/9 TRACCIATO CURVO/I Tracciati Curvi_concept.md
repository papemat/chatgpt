- Tracciati Curvi: Creazione e Modifica con Adobe Illustrator
  - Ripasso sui tracciati lineari
    → Passaggio all'introduzione dei tracciati curvi
      - Utilizzo dello strumento "Maniglia"
        → Creazione di forme curve e complesse
          - Modifica dei punti di controllo
            → Cambio della forma delle curve
              - Spezzatura delle curve
                → Creazione di angoli retti o spigoli
                  - Inversione dei tracciati
                    → Aggiunta del riempimento
                      - Utilizzo degli strumenti di selezione diretta e trasformazione
                        → Miglioramento delle geometrie