Creazione di immagini vettoriali tramite traccia, contorno e calco

- Tracciatura manuale
  - Definizione del contorno
    - Ricalco di immagini
      - Merging di immagini
        - Forma calco
          - Rinominamento file

Esami pratici per ogni passaggio
  - Seguimento degli step in ordine cronologico per risultati ottimali