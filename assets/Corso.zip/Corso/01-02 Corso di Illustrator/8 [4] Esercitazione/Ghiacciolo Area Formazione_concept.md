- Creazione di un Ghiacciolo con Tracciati e Stili
  - Forme semplici come rettangoli e smussature
    → Geometrie complesse: riflessi e ombre
  - Strumenti di selezione diretta e simmetria
    → Creazione della forma finale del ghiacciolo
  - Applicazione di stili uniformi e tracciati
    → Utilizzo di formati e metodi di colore RGB
  - Separazione dei livelli per il ghiacciolo, la sua ombra e lo sfondo