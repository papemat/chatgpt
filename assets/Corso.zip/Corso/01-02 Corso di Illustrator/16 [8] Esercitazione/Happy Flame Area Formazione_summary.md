1. Happy Flames: Esercitazione Merging Immagini

2. L'esercitazione "Happy Flames" si concentra sulla tecnica del merging di immagini, mostrando come ripetere i passaggi della lezione precedente per ottenere un risultato simile. Gli studenti vengono incoraggiati a seguire i passaggi step by step, includendo la trasformazione in tracciati, forme di tracciati e campitura a sfumature.

3. • Seguire lezione precedente su merging di immagini
• Ripetere identici passi per ottenere risultato finale
• Trasformazione in tracciati
• Trasformazione in forme di tracciati
• Campitura a sfumature
• Salvare file con e senza sfondo (pn.pn)