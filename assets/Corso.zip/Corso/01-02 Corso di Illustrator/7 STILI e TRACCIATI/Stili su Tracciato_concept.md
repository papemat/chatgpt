Personalizzazione degli Stili dei Tracciati in Adobe Illustrator

- Personalizzazione dello stile dei tracciati
  - Cambio del colore e dello spessore
    → Modifica l'aspetto visivo del tracciato
  - Inversione del verso di partenza
    → Alterna la direzione del disegno
  - Scelta di stili predefiniti
    → Applica formati standard ai tracciati
- Uniformizzazione degli estremi
  → Assicura che i punti di un tracciato siano uniformi
- Trasformazione dei tracciati in forme o freccie
  - Forme
    → Converte il tracciato in una forma geometrica
  - Freccie
    → Crea una freccia partendo dal tracciato

- Unione di due tracciati
  → Combina due linee per formare un nuovo tracciato

- Scomposizione di una forma per rivelare il tracciato e il riempimento
  - Tracciato
    → Espone la linea che compone la forma
  - Riempimento
    → Mostra il colore o l'immagine all'interno della forma