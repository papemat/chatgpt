- Tavole di disegno: fogli separati all'interno dello stesso file
  - Copiare e spostare tavole di disegno
    → Per organizzare il contenuto grafico
  - Rinominare le tavole per un ordine logico
    → Per una gestione più facile
  - Esportare tavole di disegno in formati PDF o JPEG
    → Per condividere e utilizzare i progetti in vari ambienti
- Gestire il contenuto grafico su più tavole di disegno
  - Utilizzare le tavole di disegno per organizzare progetti aziendali e presentazioni
    → Aiuta a mantenere l'ordine e la chiarezza nei progetti complessi
- Salvare con nome utilizzando tutte le tavole di disegno o un intervallo specifico
  - Copiare, spostare e cancellare tavole di disegno
    → Per adattare i progetti ai cambiamenti richiesti
  - Esportare tavole di disegno in formati PDF o JPEG
    → Per una facile condivisione dei progetti completati