Titolo: Introduzione agli Strumenti di Base di Adobe Illustrator

Paragrafo di sintesi:
In questa lezione, si esplora i principali strumenti di base di Adobe Illustrator, un software di grafica vettoriale. Si inizia con l'impostazione del file A4 in formato RGB e si passa all'area di lavoro, zoomando e spostando il foglio. Vengono presentati gli strumenti selezione, rettangolo, curvatura, penna, testo e pennello, mostrando come utilizzarli per creare forme, linee e testi. Si conclude con un breve tour dell'area colori e si incoraggia a fare pratica con questi strumenti di base.

Concetti chiave in ordine cronologico:
1. Creazione di un nuovo file A4 in formato RGB
2. Zoomare e spostare il foglio nell'area di lavoro
3. Strumento selezione (V)
4. Strumento rettangolo
5. Strumento curvatura
6. Strumento penna
7. Strumento testo
8. Strumento pennello
9. Utilizzo dell'area colori
10. Familiarità con gli strumenti di base per creare forme, linee e testi