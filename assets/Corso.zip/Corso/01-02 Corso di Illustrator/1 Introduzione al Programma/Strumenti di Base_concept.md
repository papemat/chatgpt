1. Creazione di un nuovo file A4 in formato RGB
   - Impostazione del formato RGB
     → Formato RGB per il colore
2. Zoomare e spostare il foglio nell'area di lavoro
   - Utilizzo dell'area di lavoro
     → Gestione dello spazio di lavoro
3. Strumento selezione (V)
   - Selezione di elementi grafici
     → Creazione di forme e linee
4. Strumento rettangolo
   - Creazione di rettangoli
     → Forma geometrica base
5. Strumento curvatura
   - Creazione di curve
     → Forma geometrica alternativa al rettangolo
6. Strumento penna
   - Disegno di linee e forme libere
     → Creatività e precisione nel disegno
7. Strumento testo
   - Inserimento di testi
     → Aggiunta di informazioni testuali
8. Strumento pennello
   - Applicazione di effetti e sfumature
     → Personalizzazione delle forme e dei colori
9. Utilizzo dell'area colori
   - Gestione e selezione dei colori
     → Creazione di palette personalizzate
10. Familiarità con gli strumenti di base per creare forme, linee e testi
    - Pratica e apprendimento
      → Maturità nell'utilizzo del software Adobe Illustrator