I Livelli in Adobe Illustrator

1. Livelli e sottolivelli
   → Si trovano nella paletta "Livelli"
   → Ogni nuovo elemento creato viene inserito nello stesso livello, producendo dei sottolivelli

2. Gestione dei livelli
   → I livelli possono essere rinominati e ordinati
   → È possibile spostare elementi da un livello all'altro

3. Utilizzo dei livelli in Adobe Illustrator
   → Adobe Illustrator incoraggia di solito l'utilizzo di un solo livello per la maggior parte delle grafiche vettoriali