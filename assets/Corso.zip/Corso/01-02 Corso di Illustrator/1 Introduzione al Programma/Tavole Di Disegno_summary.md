Titolo: L'uso delle Tavole di Disegno in Adobe Illustrator

Paragrafo di sintesi:
Nella lezione di oggi, si è appreso come utilizzare le tavole di disegno in Adobe Illustrator per organizzare e gestire i progetti grafici. Si è scoperto che le tavole di disegno sono fogli separati all'interno dello stesso file, ognuno con il proprio contenuto grafico. È stato mostrato come copiare, spostare e cancellare tavole di disegno, oltre a rinominarle per un ordine più logico. Inoltre, si è discusso su come esportare le tavole di disegno in formati PDF o JPEG.

Concetti chiave:
1. Tavole di disegno: fogli separati all'interno dello stesso file
2. Copiare e spostare tavole di disegno
3. Rinominare le tavole per un ordine logico
4. Esportare tavole di disegno in formati PDF o JPEG
5. Gestire il contenuto grafico su più tavole di disegno
6. Utilizzare le tavole di disegno per organizzare progetti aziendali e presentazioni
7. Salvare con nome utilizzando tutte le tavole di disegno o un intervallo specifico