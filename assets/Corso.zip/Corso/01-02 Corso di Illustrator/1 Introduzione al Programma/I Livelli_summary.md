Titolo: I Livelli in Adobe Illustrator

Paragrafo di sintesi:
Nella lezione, l'insegnante spiega i concetti base dei livelli e sottolivelli in Adobe Illustrator. I livelli si trovano all'estrema destra del software e sono contenuti nella paletta "Livelli". Ogni nuovo elemento creato viene inserito di default nello stesso livello, producendo dei sottolivelli. L'insegnante dimostra come creare, rinominare e gestire i livelli e i sottolivelli, e come spostare elementi da un livello all'altro.

Concetti chiave:
1. Livelli e sottolivelli si trovano nella paletta "Livelli".
2. Ogni nuovo elemento creato viene inserito nello stesso livello, producendo dei sottolivelli.
3. I livelli possono essere rinominati e ordinati.
4. È possibile spostare elementi da un livello all'altro.
5. Adobe Illustrator incoraggia di solito l'utilizzo di un solo livello per la maggior parte delle grafiche vettoriali.