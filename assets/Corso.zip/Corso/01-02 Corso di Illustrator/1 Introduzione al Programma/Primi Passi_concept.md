Adobe Illustrator
  ├── Sviluppato da Adobe
  │   └── Software di grafica vettoriale
  ├── Utilizza i vettori per esprimere le forme all'interno dell'area di disegno
  │   └── Consente un'elevata qualità della stampa anche quando si lavora con grandi dimensioni o scale
  ├── Offre una vasta gamma di strumenti
  │   ├── Per la creazione di loghi
  │   ├── Per la creazione di icone
  │   └── Per la creazione di flyer e altri materiali stampabili senza l'utilizzo di foto
  └── Offre una interfaccia intuitiva e accessibili strumenti che facilitano il processo di creazione