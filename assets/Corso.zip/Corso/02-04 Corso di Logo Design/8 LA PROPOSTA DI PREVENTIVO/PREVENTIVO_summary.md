1. Preventivo per un Logo Design: Fasi e Pagamenti

2. In questa lezione, si affronta la creazione di un preventivo personalizzato per un logo design, suddiviso in tre fasi: brainstorming e ricerca (fase 1), digitalizzazione e miglioramento dei sketch selezionati (fase 2) e scelta finale del logo da parte del cliente (fase 3). Il preventivo prevede pagamenti segmentali del 33% in ciascuna fase, con l'opzione di aggiungere costi extra per modifiche ulteriori richieste dal cliente.

3. Bullet chiave:
- Preventivo personalizzato per logo design
- Suddivisione in tre fasi: brainstorming e ricerca (fase 1), digitalizzazione e miglioramento (fase 2), scelta finale del logo (fase 3)
- Pagamenti segmentali del 33% in ciascuna fase
- Opzione di aggiungere costi extra per modifiche ulteriori richieste dal cliente
- Presentazione del preventivo in formato PDF e invio via email
- Condivisione della cartella vettoriale finale in formato zip
- Definizione di deadline temporali per ciascuna fase (opzionale)