1. Preventivo per un Logo Design: Fasi e Pagamenti
   - Brainstorming e ricerca (fase 1)
     → Ricerca e identificazione delle idee iniziali per il logo
     → Creazione di sketch preliminari
   - Digitalizzazione e miglioramento dei sketch selezionati (fase 2)
     → Trasformazione dei sketch in file digitali
     → Modifica e ottimizzazione dei design
   - Scelta finale del logo da parte del cliente (fase 3)
     → Selezione del logo definitivo tra quelli proposti
     → Condivisione della versione finale del logo
2. Pagamenti
   - Pagamento segmentale del 33% in ciascuna fase
     → Fase 1: Brainstorming e ricerca (1/3 del totale)
     → Fase 2: Digitalizzazione e miglioramento (1/3 del totale)
     → Fase 3: Scelta finale del logo (1/3 del totale)
   - Opzione di aggiungere costi extra per modifiche ulteriori richieste dal cliente
3. Altri dettagli
   - Presentazione del preventivo in formato PDF e invio via email
   - Condivisione della cartella vettoriale finale in formato zip
   - Definizione di deadline temporali per ciascuna fase (opzionale)