La Fase 3 del Logo Design:
    → Scelta Finale e Revisione
        → Cliente sceglie il concetto più adatto
            → Perfezionamento del logo
                → Mantenere geometrie bloccate
                    → Apportare modifiche ai dettagli (lettering, posizionamento delle immagini, interazioni tra le forme)
                        → Equilibrio complessivo del logo
        → Ultima revisione con il cliente
            → Invio della bozza finale per conferma
                → Senza possibilità di apportare cambiamenti significativi al logo
        → Foto inserimento e Consegna della cartella vettoriale
            → Aggiunta di elementi fotografici per completare il logo
            → Trasmissione del file completo al cliente