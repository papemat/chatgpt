Esercitazione Fase 3: Perfezzionamento del Logo

1. Selezione del logo tra quelli digitalizzati → Liminalizzazione del logo scelto
2. Liminalizzazione del logo scelto → Ottimizzazione del logo per ottenere un risultato convincente e bilanciato
3. Ottimizzazione del logo per ottenere un risultato convincente e bilanciato → Due revisioni finali del lavoro svolto
4. Due revisioni finali del lavoro svolto → Fine della formazione
5. Fine della formazione → Presentazione dei risultati ottenuti