- Terminologia nel Logo Design
  - Famiglie di Loghi
    - Old School
      → Elementi che richiamano il passato
      → Utilizzati da professionisti del settore artigianale e manuale
    - Minimal
      → Loghi semplici e semplificati
      → Grande attenzione per i dettagli come linee sottili e forme astratte
    - Stemma
      → Richiamano lo stemma
      → Utilizzati principalmente da istituzioni e aziende storiche
    - Mandala
      → Ispirati ai mandala asiatici
      → Ricchi di elementi speculari e simmetrici
    - Monogram
      → Composti dalle iniziali del nome o cognome del cliente
    - Illustrato
      → Assomigliano a illustrazioni
      → Utilizzati principalmente per target giovani o bambini
  - Famiglie di Caratteri (Font)
    - Sans Serif (Senza Grazie)
      → Caratteri moderni senza elementi decorativi alle estremità delle lettere
    - Serif (Con Grazie)
      → Caratteri più antichi e arcaici, con elementi decorativi alle estremità delle lettere
    - Handwriting
      → Caratteri simili a quelli scritti a mano
      → Utilizzati principalmente per inviti e biglietti di auguri