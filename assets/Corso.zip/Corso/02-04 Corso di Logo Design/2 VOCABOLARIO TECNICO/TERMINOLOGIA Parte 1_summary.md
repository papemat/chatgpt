1. Terminologia nel Logo Design: Famiglie di Loghi e Caratteri

2. In questa lezione, verranno esplorate le diverse tipologie di loghi e caratteri utilizzati nel logo design, suddividendoli in sei grandi famiglie: old school, minimal, stemma, mandala, monogram e illustrato. Verrà inoltre analizzato il significato e l'utilizzo dei termini tecnici legati ai font e ai caratteri.

3. Famiglie di Loghi:
   - Old School: loghi con elementi che richiamano il passato, utilizzati principalmente da professionisti del settore artigianale e manuale.
   - Minimal: loghi semplici e semplificati, con grande attenzione per i dettagli come linee sottili e forme astratte.
   - Stemma: loghi che richiamano lo stemma, utilizzati principalmente da istituzioni e aziende storiche.
   - Mandala: loghi ispirati ai mandala asiatici, ricchi di elementi speculari e simmetrici.
   - Monogram: loghi composti dalle iniziali del nome o cognome del cliente.
   - Illustrato: loghi che assomigliano a illustrazioni, utilizzati principalmente per target giovani o bambini.

4. Famiglie di Caratteri (Font):
   - Sans Serif (Senza Grazie): caratteri moderni senza elementi decorativi alle estremità delle lettere.
   - Serif (Con Grazie): caratteri più antichi e arcaici, con elementi decorativi alle estremità delle lettere.
   - Handwriting: caratteri simili a quelli scritti a mano, utilizzati principalmente per inviti e biglietti di auguri.