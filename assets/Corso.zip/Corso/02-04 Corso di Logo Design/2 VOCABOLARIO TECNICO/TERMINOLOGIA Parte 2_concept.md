Geometria nei Loghi: Concetti Chiave
├── Pianta del logo
│   ├── Poligoni inscritti
│   │   ├── Quadrato
│   │   ├── Circolo
│   │   ├── Rettangolo orizzontale
│   │   └── Rettangolo verticale
│   └── Logo può occupare interamente la piantana o il lettering al di fuori
├── Offset
│   ├── Sbalzi al di fuori o all'interno della forma (circonferenza)
│   └── Termine grafico utilizzato nel logo design
├── Smussatura degli angoli
│   ├── Angolo netto, arrotondato e raggiato
│   └── Gradi di smussatura (es. 3 mm)
└── Sfondi
    ├── Logo neutro senza sfondo (logo semplice)
    ├── Logo con sfondo colorato
    └── Consegnare loghi in positivo e negativo (con sfondo scuro)
├── Shading e sfumatura
│   ├── Ombra tra elementi o sulla superficie del logo
│   └── Passaggio tra diverse tonalità (massimo 2 tinte)