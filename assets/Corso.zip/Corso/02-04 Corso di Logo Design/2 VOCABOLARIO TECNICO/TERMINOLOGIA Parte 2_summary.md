1. Geometria nei Loghi: Concetti Chiave

2. In questa lezione, si esplorano i concetti geometrici fondamentali utilizzati nel design di loghi, come la pianta del logo (poligoni inscritti), l'offset (sbalzi al di fuori o all'interno della forma), la smussatura degli angoli (raggiata e arrotondata) e gli sfondi. Inoltre, si discutono le differenze tra shading (ombra) e sfumatura (passaggio tra diverse tonalità), che sono essenziali per creare loghi bilanciati e efficaci.

3. Pianta del logo:
   - Poligoni inscritti (quadrato, circolo, rettangolo orizzontale, rettangolo verticale)
   - Logo può occupare interamente la piantana o il lettering al di fuori
4. Offset:
   - Sbalzi al di fuori o all'interno della forma (circonferenza)
   - Termine grafico utilizzato nel logo design
5. Smussatura degli angoli:
   - Angolo netto, arrotondato e raggiato
   - Gradi di smussatura (es. 3 mm)
6. Sfondi:
   - Logo neutro senza sfondo (logo semplice)
   - Logo con sfondo colorato
   - Consegnare loghi in positivo e negativo (con sfondo scuro)
7. Shading e sfumatura:
   - Ombra tra elementi o sulla superficie del logo
   - Passaggio tra diverse tonalità (massimo 2 tinte)