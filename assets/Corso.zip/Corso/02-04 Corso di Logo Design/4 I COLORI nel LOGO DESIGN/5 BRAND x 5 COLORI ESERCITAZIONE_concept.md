- Analisi dei Loghi: Colore e Brand
  - In questa lezione, si è esaminato come il colore influenzi la percezione del brand e del cliente.
    → Esercizio:
      - Selezionare 5 loghi famosi
        → Identificare il colore predominante in ciascuno
          → Analizzare il brand dietro al logo, non solo il logo stesso
            → Riflettere sulla comunicazione e sul percepito del brand
              → Considerare l'efficacia del colore nel branding
  - Loghi da analizzare:
    - Ferrero
      → Comunicazione del brand attraverso il logo e il colore
        → Impatto emotivo e percettivo sul cliente
          → Efficacia del colore nel rappresentare il valore del brand
    - Nike
    - Nutella
    - Decathlon
    - Altri loghi giganteschi (a scelta)
  - Analisi del Brand:
    - Valutare l'accuratezza dei colori utilizzati nei loghi famosi
      → Relazionare i risultati con quanto studiato sulla teoria dei colori
        → Concludere sull'importanza del colore nel branding efficace
  - Riscontro e Prova del 9: