Colori nel Logo Design
├── Importanza dei colori nel logo design
│   ├── Influenza l'interpretazione del logo
│   └── Influensa il messaggio del logo
├── Regole per la scelta dei colori
│   ├── Usare una o massimo due tinte
│   │   └── Evitare loghi troppo sgargianti
│   ├── Considerare le differenze tra RGB e CMYK
│   └── Progettare i loghi in bianco e nero prima di aggiungere i colori
├── Scegliere i colori appropriati
│   ├── Scegliere i colori in base all'obiettivo del logo
│   │   └── Considerare il target di riferimento
│   └── Prendere in considerazione le sfumature dei colori
│       └── Creare un logo efficace e memorabile