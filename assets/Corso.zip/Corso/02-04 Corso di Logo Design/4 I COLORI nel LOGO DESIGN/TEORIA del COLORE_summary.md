1. Colori nel Logo Design
2. In questa lezione si concentra sull'importanza dei colori nel logo design, evidenziando come i colori possano influenzare l'interpretazione e il messaggio del logo.
3. Utilizzare una o massimo due tinte per evitare loghi troppo sgargianti
4. Considerare le differenze tra RGB e CMYK nella scelta dei colori
5. Progettare i loghi in bianco e nero prima di aggiungere i colori
6. Scegliere i colori in base all'obiettivo del logo e al target di riferimento
7. Prendere in considerazione le sfumature dei colori per creare un logo efficace e memorabile