1. Analisi dei Loghi: Colore e Brand

2. In questa lezione, si è esaminato come il colore influenzi la percezione del brand e del cliente. Ora, l'esercizio proposto richiede di analizzare 5 loghi famosi con un colore predominante. L'obiettivo è comprendere come il colore abbia contribuito alla potenza del brand.

3. Esercizio:
   - Selezionare 5 loghi famosi
   - Identificare il colore predominante in ciascuno
   - Analizzare il brand dietro al logo, non solo il logo stesso
   - Riflettere sulla comunicazione e sul percepito del brand
   - Considerare l'efficacia del colore nel branding

4. Loghi da analizzare:
   - Ferrero
   - Nike
   - Nutella
   - Decathlon
   - Altri loghi giganteschi (a scelta)

5. Analisi del Brand:
   - Comunicazione del brand attraverso il logo e il colore
   - Impatto emotivo e percettivo sul cliente
   - Efficacia del colore nel rappresentare il valore del brand

6. Riscontro e Prova del 9:
   - Valutare l'accuratezza dei colori utilizzati nei loghi famosi
   - Relazionare i risultati con quanto studiato sulla teoria dei colori
   - Concludere sull'importanza del colore nel branding efficace