Redesign del Logo Kama
└→ Interpretazione del nome Kama come nome proprio
└→ Stravolgimento della componente cromatica e formale
└→ Orientamento al futuro
└→ Creazione di un payoff di accompagnamento (opzionale)
└→ Presentazione di un documento con i passaggi per arrivare alla cartella vettoriale del nuovo logo