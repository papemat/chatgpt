1. Titolo: Redesign del Logo Kama - Effetto Sorpresa

2. Paragrafo di sintesi:
Nell'ultima esercitazione, i partecipanti sono stati invitati a rinnovare il logo di Kama, un'accademia di formazione digitale. Senza indicazioni su ciò che rappresenta Kama, gli studenti hanno dovuto interpretarlo come se fosse il nome proprio di una persona. L'obiettivo era stravolgere la componente cromatica e formale del logo, orientandolo al futuro. I partecipanti potevano anche inventare un payoff di accompagnamento all'accademia.

3. Bullet con i concetti chiave in ordine cronologico:
- Redesign del logo Kama
- Interpretazione del nome Kama come nome proprio
- Stravolgimento della componente cromatica e formale
- Orientamento al futuro
- Creazione di un payoff di accompagnamento (opzionale)
- Presentazione di un documento con i passaggi per arrivare alla cartella vettoriale del nuovo logo