Il brief: guida passo-passo per una fase di ricerca efficace

1. Preparazione mentale:
   → Essere pronti ad ascoltare e carpire tutte le informazioni rilevanti dal cliente.

2. Indagine sull'ispirazione, gli obiettivi e le aspettative del cliente:
   → Identificare l'origine dell'ispirazione
   → Definire gli obiettivi specifici
   → Valutare le aspettative del target

3. Analisi della mission e dei punti di forza dell'azienda:
   → Comprensione profonda della missione aziendale
   → Identificazione dei punti di forza unici

4. Ricerca sulla concorrenza e il passato del logo:
   → Analisi delle strategie competitive
   → Valutazione del passato del logo e delle sue evoluzioni

5. Definizione delle "must-have" e "nice-to-have":
   → Identificare le caratteristiche essenziali (must-have)
   → Determinare le caratteristiche desiderabili (nice-to-have)

6. Indagine sulle modalità di utilizzo del logo:
   → Valutazione su prodotti e servizi
   → Considerazione sulla comunicazione e il target

7. Raccolta di tutte le informazioni su carta per una pianificazione efficace:
   → Organizzazione delle informazioni raccolte
   → Pianificazione dei prossimi passi per la creazione del logo