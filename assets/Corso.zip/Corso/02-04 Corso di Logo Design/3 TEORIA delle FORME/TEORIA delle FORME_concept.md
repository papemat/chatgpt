1. Gestalt: Principi di Forma nella Design Grafico

2. → In questa lezione, si esplora la corrente tedesca del 1910 nota come Gestalt, che affronta i principi di forma e percezione visiva. Si discute dei concetti chiave della Gestalt, tra cui esperienza passata, destino comune, continuità di direzione, chiusura, vicinanza, pregnanza e similitudine.

3. → Principi di Gestalt:
   - Esperienza Passata: Considera il bagaglio esperienziale del pubblico
   - Destino Comune: Elementi orientati nello stesso verso creano continuità
   - Continuità di Direzione: Orientamento degli elementi che crea percezione di un insieme
   - Chiusura: Forme chiuse che si percepiscono come interconnesse
   - Vicinanza: Elementi vicini a creare leggibilità e interconnessione
   - Pregnanzza: Interazione tra forme per creare riconoscibilità
   - Similitudine: Somiglianza tra elementi che crea familiarità e riconoscibilità

4. → Esempi di applicazione dei principi di Gestalt in logotipi:
   - Logo Carrefour utilizza la legge della chiusura per creare una C visiva
   - Logo IBM utilizza la vicinanza per combinare le lettere B e M
   - Logo Adobe utilizza la pregnanza per incorporare un secondo triangolo all'interno del primo

5. → L'uso di tecniche di sketching su carta è fondamentale per applicare i principi di Gestalt nella fase iniziale di design del logo, consentendo al designer di esplorare diverse opzioni e ottimizzare il risultato finale.