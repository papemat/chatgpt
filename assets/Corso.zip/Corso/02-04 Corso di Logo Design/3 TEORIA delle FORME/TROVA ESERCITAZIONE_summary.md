1. Ricerca di loghi rappresentativi delle leggi

2. In questa esercitazione, gli studenti vengono invitati a cercare online luoghi che rappresentino ogni singolo principio e legge discussi durante le lezioni sulle forme. L'obiettivo è ripercorrere le slide prese in esame e trovare sette loghi, uno per ogni principio, oltre a un ottavo logo rappresentante la legge della somiglianza.

3. Principi e leggi da rappresentare:
   - Principio dell'esperienza passata
   - Principio del destino comune
   - Principio della continuità di direzione
   - Legge di chiusura (Legge della somiglianza o principio della somiglianza)
   - Legge della vicinanza
   - Legge della pregnanza

4. Studenti devono cercare loghi su web, scaricarli in formato JPEG, PNG, EPS o vettoriale e metterli in una cartella.

5. L'esercitazione si conclude con un riepilogo visivo degli esempi trovati per ogni principio e legge.