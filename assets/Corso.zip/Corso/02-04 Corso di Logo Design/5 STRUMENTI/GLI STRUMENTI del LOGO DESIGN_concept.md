1. Strumenti del Logo Designer
   2. In questa lezione, si esplorano gli strumenti essenziali per il logo design, tra cui la mano libera (sketching), Adobe Photoshop e Adobe Illustrator. Si discute anche l'importanza di una buona connessione internet e computer.
      - Sketching a mano libera
        → Libero da limiti digitali
        → Ricerca e brainstorming con parole chiave
        → Bozzetti per invio al cliente
      - Adobe Photoshop
        → Pulizia delle foto e inserimento di sketch
        → Elaborazione del logo, colorazione e foto
        → Foto inserite su vari materiali (magliette, camion, palazzi)
      - Adobe Illustrator
        → Programma vettoriale per matematiche delle forme
        → Vettorializzazione dei bozzetti provenienti da Photoshop e sketching
   6. Web e portali di ispirazione
   7. Importanza di una connessione internet stabile