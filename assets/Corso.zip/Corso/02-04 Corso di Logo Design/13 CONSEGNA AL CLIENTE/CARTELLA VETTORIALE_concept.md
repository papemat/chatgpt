La Cartella Vettoriale: Passaggio Cruciale nel Workflow dei Loghi

- Trasmissione del logo in tutte le sue forme
  - Indipendenza del logo dalle fonti originali
    - Evitare il momento di passaggio tra progetto concluso e nuovo incarico
      - Creazione di una buona sensazione per il cliente
        - Invio di un'e-mail con elenco puntato delle componenti della cartella vettoriale

- Inclusione di file JPEG pronti per l'uso, file vettoriali e PNG senza sfondo
  - Creazione di versioni positive e negative del logo
    - Conversione dei tracciati in forme
      - Utilizzo di fondi contrastanti per i loghi
        - Esportazione dei file in formato JPEG, PNG e PDF

- Invio di formati minimi fondamentali (Illustrator, EPS, JPEG, PNG) al cliente
  - Comunicazione con il cliente per richiedere variazioni aggiuntive