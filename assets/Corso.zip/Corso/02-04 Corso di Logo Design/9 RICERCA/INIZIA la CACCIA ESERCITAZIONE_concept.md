Creazione Mood Board
    - Scaricare il PDF delle parole chiave
        → Identificare le parole chiave nel PDF
            → Estrarre almeno 20 immagini basate sulle parole chiave
                → Organizzare le immagini in un PDF o una cartella
                    → Utilizzare vari formati di immagine (vettori, JPEG, PNG)
                        → Condividere i risultati con il cliente per includere i suoi punti di vista
    → Inizia lezioni di sketching e creazione dei primi conti da parte degli studenti