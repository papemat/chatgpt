1. Logo Design: Ricerca e Mood Board
2. In questa lezione, si è discusso del processo di ricerca nel design dei loghi, focalizzandosi sulla creazione di una mood board. Si è esplorato come trovare ispirazione su Google, selezionare immagini che rappresentano i concetti chiave e i mood desiderati dal cliente, e come utilizzare queste immagini per guidare la fase successiva dello sketching.
3. Conoscere il cliente: Paolo, un coltivatore che vuole creare un logo per un gruppo di coltivatori con un'impronta ecologica e sostenibile
4. Identificare le parole chiave: Terra, insieme, manualità, ritorno al passato, basso impatto ambientale, salute, prodotti diversi ma con la stessa mission
5. Creare una mood board con immagini ispiratrici che rappresentano i concetti e i colori desiderati dal cliente
6. Utilizzare fonti come Google Images e siti web come Freepic per trovare immagini vettoriali gratuite
7. Procedere alla fase di sketching, sia digitale che manuale, basandosi sulle immagini della mood board e sui concetti chiave identificati