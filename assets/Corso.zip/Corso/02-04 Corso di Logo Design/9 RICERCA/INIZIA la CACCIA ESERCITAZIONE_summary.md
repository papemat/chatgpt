1. Creazione Mood Board
2. In questa esercitazione, gli studenti saranno guidati nella creazione di una mood board basata sulle parole chiave presentate nel PDF di Paolo di Conterranea. Gli studenti dovranno estrarre almeno 20 immagini dalle parole chiave fornite e organizzarle in un unico file PDF o cartella.
3. - Scaricare il PDF delle parole chiave
- Identificare le parole chiave nel PDF
- Estrarre almeno 20 immagini basate sulle parole chiave
- Organizzare le immagini in un PDF o una cartella
- Utilizzare vari formati di immagine (vettori, JPEG, PNG)
- Condividere i risultati con il cliente per includere i suoi punti di vista
4. L'esercitazione si conclude con l'inizio delle lezioni di sketching e la creazione dei primi conti da parte degli studenti.