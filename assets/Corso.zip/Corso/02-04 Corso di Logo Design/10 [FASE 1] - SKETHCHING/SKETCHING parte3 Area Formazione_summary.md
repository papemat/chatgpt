1. Sketching per il Logo Design: Fase 1

In questo capitolo, l'insegnante guida gli studenti attraverso la prima fase dello sketching orientato al logo design. La lezione inizia con un breve riassunto delle basi dello sketching viste nelle lezioni precedenti e si concentra sulla progettazione di loghi utilizzando forme geometriche semplici come rettangoli, triangoli e poligoni.

2. Paragrafo di sintesi
L'insegnante inizia spiegando l'importanza di un buon brief con il cliente e di basarsi sulle teorie formali per guidare la creazione dei loghi. Gli studenti vengono incoraggiati a utilizzare carta e penna per mantenere una tecnica più dinamica e meno vincolata rispetto al lavoro digitale. L'obiettivo è di produrre un gran numero di proposte creative in un breve lasso di tempo, esplorando diverse forme geometriche e combinazioni di queste forme per creare loghi interessanti e memorabili.

3. Concetti chiave:
- Importanza di un buon brief con il cliente
- Utilizzo delle teorie formali per guidare la progettazione dei loghi
- Utilizzo della carta e della penna per mantenere una tecnica dinamica
- Esplorazione di diverse forme geometriche (rettangoli, triangoli, poligoni)
- Creazione di un gran numero di proposte creative in breve tempo
- Combinazione di forme geometriche per creare loghi interessanti e memorabili
- Utilizzo di linee dinamiche e curve per aggiungere movimento e vita ai loghi
- Importanza dello sketching per generare idee innovative e audaci