- Fase 1 di Logo Design: Lo Sketching
  - Obiettivo: Imparare le basi dello sketching per creare bozzetti di logo su carta
    - Inizia con esercizi di riscaldamento
      → Esercizi di riscaldamento:
        - Linee dinamiche
        - Triangoli
    - Prosegue con la tecnica dello sketching
      → Tecnica dello sketching:
        - Utilizzo della penna per creare linee dinamiche
        - Creazione di triangoli con linee intersecantisi
    - Enfatizzazione dei disegni
      → Enfatizzazione dei disegni:
        - Ripasso dinamico delle linee per dare potenza al logo
        - Sfumini e linee più scure per enfatizzare gli angoli e le bordature
  - Importanza dello sketching nel processo di progettazione del logo
    → Esplorazione di idee creative e originali
    → Evitare la vincolatura alle geometrie digitali
    → Creare bozzetti che colpiscono il cliente o lo studio stesso