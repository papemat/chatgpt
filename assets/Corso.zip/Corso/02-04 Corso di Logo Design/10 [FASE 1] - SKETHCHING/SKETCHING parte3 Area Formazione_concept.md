1. Sketching per il Logo Design: Fase 1
   - Inizia con un breve riassunto delle basi dello sketching viste nelle lezioni precedenti
     → Utilizzo della carta e della penna per mantenere una tecnica dinamica
     → Esplorazione di diverse forme geometriche (rettangoli, triangoli, poligoni)
   - Si concentra sulla progettazione di loghi utilizzando forme geometriche semplici

2. Paragrafo di sintesi
   - L'insegnante inizia spiegando l'importanza di un buon brief con il cliente
     → Importanza di un buon brief con il cliente
     → Utilizzo delle teorie formali per guidare la creazione dei loghi
   - Gli studenti vengono incoraggiati a utilizzare carta e penna
     → Utilizzo della carta e della penna per mantenere una tecnica dinamica
   - L'obiettivo è di produrre un gran numero di proposte creative in un breve lasso di tempo
     → Creazione di un gran numero di proposte creative in breve tempo
   - Esplorando diverse forme geometriche e combinazioni di queste forme per creare loghi interessanti e memorabili
     → Combinazione di forme geometriche per creare loghi interessanti e memorabili

3. Concetti chiave:
   - Importanza di un buon brief con il cliente
   - Utilizzo delle teorie formali per guidare la progettazione dei loghi
   - Utilizzo della carta e della penna per mantenere una tecnica dinamica
   - Esplorazione di diverse forme geometriche (rettangoli, triangoli, poligoni)
   - Creazione di un gran numero di proposte creative in breve tempo
   - Combinazione di forme geometriche per creare loghi interessanti e memorabili
   - Utilizzo di linee dinamiche e curve per aggiungere movimento e vita ai loghi
   - Importanza dello sketching per generare idee innovative e audaci