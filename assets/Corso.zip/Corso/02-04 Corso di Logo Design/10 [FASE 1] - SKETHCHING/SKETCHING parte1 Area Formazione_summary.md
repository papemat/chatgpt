1. Fase 1 di Logo Design: Lo Sketching
2. In questa lezione, l'obiettivo è imparare le basi dello sketching per creare bozzetti di logo su carta. Si inizierà con esercizi di riscaldamento come linee dinamiche e triangoli, poi si passerà a enfatizzare i disegni con sfumini e linee più scure. Lo sketching è un'importante fase del processo di progettazione di un logo che permette di esplorare idee creative e originali.

3. Esercizi di riscaldamento:
   - Linee dinamiche
   - Triangoli
4. Tecnica dello sketching:
   - Utilizzo della penna per creare linee dinamiche
   - Creazione di triangoli con linee intersecantisi
5. Enfatizzazione dei disegni:
   - Ripasso dinamico delle linee per dare potenza al logo
   - Sfumini e linee più scure per enfatizzare gli angoli e le bordature
6. Importanza dello sketching nel processo di progettazione del logo:
   - Esplorazione di idee creative e originali
   - Evitare la vincolatura alle geometrie digitali
   - Creare bozzetti che colpiscono il cliente o lo studio stesso