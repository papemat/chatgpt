1. Lavorare sui triangoli: esercizi di sketching avanzati
   - Creazione di un triangolo utilizzando linee dinamiche
     → Utilizza il polso forte per creare linee dinamiche
   - Enfatizzazione delle linee per creare forme più definite
     → Aiuta a dare chiarezza alle forme
   - Sfumino per dare profondità e completezza alle forme
     → Aggiunge realismo e volume alle figure
   - Tecnica della campitura per riempire superfici in modo rapido ed efficace
     → È un metodo pratico per completare le forme
   - L'importanza di mantenere un'impostazione tecnica chiara e precisa
     → Assicura che il disegno sia ben strutturato
   - Il polso forte è fondamentale per creare linee dinamiche e tecniche accurate
     → Contribuisce alla fluidità e al controllo nel disegno
2. La prossima lezione si concentrerà su come correggere gli errori e lavorare su forme più complesse, consolidando le basi tecniche apprese in questo esercizio.