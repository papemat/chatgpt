Titolo: Lo Sketching dei Rettangoli e delle Circonferenze

Paragrafo di sintesi:
Nella seconda lezione sullo sketching, l'insegnante guida i disegnatori attraverso la creazione di rettangoli smussati e circolari. Inizia con un esempio di ovale per padroneggiare la circonferenza, spiegando come l'ovale trasmetta informazioni necessarie al cervello e alla mano. Prosegue con sfumature sulla circolarità e il movimento oscillatorio, sottolineando che nei bozzetti non è necessario creare cerchi perfetti. L'insegnante incoraggia a enfatizzare le reggetture e a non avere paura di arricchire lo sketch con dettagli e particolari. Infine, presenta alcuni esempi di loghi creati nello sketching e annuncia che nella prossima lezione si procederà con l'amplificazione dei fogli e la creazione di differenziazioni tra superfici e campiture.

Concetti chiave:
1. Creazione di rettangoli smussati e circolari
2. Ovale come base per padroneggiare la circonferenza
3. Sfumature sulla circolarità e movimento oscillatorio
4. Bozzetto: non necessario cerchi perfetti
5. Enfatizzare le reggetture e arricchire lo sketch con dettagli
6. Esempi di loghi creati nello sketching
7. Prossima lezione: amplificazione dei fogli e differenziazioni tra superfici e campiture