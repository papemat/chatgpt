Lo Sketching dei Rettangoli e delle Circonferenze

1. Creazione di rettangoli smussati e circolari
   - Ovale come base per padroneggiare la circonferenza
     → Ovale trasmette informazioni necessarie al cervello e alla mano
   - Sfumature sulla circolarità e movimento oscillatorio
     → Non è necessario creare cerchi perfetti

2. Enfatizzare le reggetture e arricchire lo sketch con dettagli
   - Incoraggiamento a non avere paura di arricchire lo sketch con dettagli e particolari

3. Esempi di loghi creati nello sketching
   - Presentazione di alcuni esempi di loghi creati nello sketching

4. Prossima lezione: amplificazione dei fogli e differenziazioni tra superfici e campiture
   → Annuncio della prossima lezione che si procederà con l'amplificazione dei fogli e la creazione di differenziazioni tra superfici e campiture