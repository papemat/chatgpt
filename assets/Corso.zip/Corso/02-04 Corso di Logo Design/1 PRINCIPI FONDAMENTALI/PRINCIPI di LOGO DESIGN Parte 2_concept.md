Logotipi e Pittogrammi: Analisi e Classificazione

    Paragrafo di sintesi:
        - Differenze tra logotipi e pittogrammi
            → Logotipi: combinazione delle parole "logo" e "tipo", rappresentano una parola o lettere
            → Pittogrammi: simboli visivi riconoscibili che rappresentano un'idea, un prodotto o un servizio
        → Entrambi sono essenziali per creare un marchio forte e memorabile

    Bullet con i concetti chiave in ordine cronologico:
        - Tipi di logotipi: monogramma, tipogramma, emblema, lettering
        - Classificazione dei pittogrammi: riconoscibili e astratti
        - Importanza della scelta del carattere e dello stile per la creazione di un logo
        - Utilizzo di sfondi geometrici o campiture per creare marchi emblema
        - Monogramma: utilizzo di lettering sulle iniziali di un nome
        - Pittogrammi astratti: possono essere minimale, complesso, colorato o monocromo
        - L'importanza della terminologia nel mondo del branding e del logo design
        - Commissione di un logo: richiedere a un professionista per un brand fatto con un disegnino (pittografo) invece di chiedere solo un logo.