1. Logo Design: Analisi del Logo a 360 Gradi

2. In questa prima lezione del corso di Logo Design, si affronta la differenza tra il termine "logo" e "brand", spiegando che il logo è l'insieme degli elementi grafici che rendono riconoscibile un brand. Il brand rappresenta invece i valori e l'identità di un'azienda o professionista, mentre il logo ne è la rappresentazione visiva.

3. Concetti chiave:
   - Logo: insieme di elementi grafici per rappresentare un brand
   - Brand: insieme dei valori che un'azienda o professionista trasmette al pubblico
   - Differenza tra logo e marchio (registrato commercialmente)
   - Logo risponde a domande dirette sulle caratteristiche visive di una persona o azienda
   - Brand rappresenta la percezione trasversale del pubblico su un'azienda o professionista
   - Logo design fa parte del mondo della grafica e dell'identità visiva