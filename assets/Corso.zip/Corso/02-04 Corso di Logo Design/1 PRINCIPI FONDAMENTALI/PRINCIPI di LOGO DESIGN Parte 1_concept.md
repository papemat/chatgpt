- Logo Design: Analisi del Logo a 360 Gradi
  - Differenza tra logo e brand
    - Logo: insieme di elementi grafici per rappresentare un brand
      → Risponde a domande dirette sulle caratteristiche visive di una persona o azienda
    - Brand: insieme dei valori che un'azienda o professionista trasmette al pubblico
      → Rappresenta la percezione trasversale del pubblico su un'azienda o professionista
  - Logo vs. Marchio (registrato commercialmente)
    → La differenza tra logo e marchio riguarda l'aspetto legale e il riconoscimento commerciale

- Logo Design: Analisi del Logo a 360 Gradi
  - Logo design nel mondo della grafica e dell'identità visiva
    → Fa parte del processo di creazione degli elementi grafici che rappresentano un brand