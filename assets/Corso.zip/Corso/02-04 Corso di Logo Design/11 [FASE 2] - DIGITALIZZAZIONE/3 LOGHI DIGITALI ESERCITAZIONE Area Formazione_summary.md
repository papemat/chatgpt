1. Trasposizione in vettoriale dei loghi

2. In questa esercitazione, gli studenti saranno guidati attraverso il processo di trasformazione manuale dei loro sketch creati nelle lezioni precedenti in immagini vettoriali digitali. Gli obiettivi principali includono la digitalizzazione di almeno tre sketch per arrivare alla scelta finale del look desiderato e prepararsi per l'ultima lezione.

3. Bullet points:
   - Rivedere i sketch creati nelle lezioni precedenti
   - Selezionare 3-10 sketch per la trasformazione in immagini vettoriali
   - Digitalizzare manualmente i sketch scelti in formati vettoriali
   - Scegliere il miglior look tra le varie opzioni digitalizzate
   - Prepararsi per l'ultima lezione successiva all'esercitazione