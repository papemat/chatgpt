Digitalizzazione dello Sketch in Photoshop

1. Scansione o fotografia del sketch → Rotazione dell'immagine
2. Creazione di nuovi livelli → Utilizzo dello strumento scalpello per isolare le forme
3. Modifica dei contrasti e delle luci → Aggiunta di colori (opzionale)
4. Preparazione del logo per la presentazione al cliente