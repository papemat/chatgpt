Trasposizione in vettoriale dei loghi

  → Rivedere i sketch creati nelle lezioni precedenti
    → Selezionare 3-10 sketch per la trasformazione in immagini vettoriali
      → Digitalizzare manualmente i sketch scelti in formati vettoriali
        → Scegliere il miglior look tra le varie opzioni digitalizzate
          → Prepararsi per l'ultima lezione successiva all'esercitazione