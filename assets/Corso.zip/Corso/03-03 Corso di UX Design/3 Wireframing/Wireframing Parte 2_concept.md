- Progettazione sito ristorante
  - User personas: Giulio e Guido
    → Esigenze specifiche
      - Pagine secondarie dedicate a vivande, video, ristorante e location esterna
        → Intestazione con titolo e immagine principale
        → Testo descrittivo conciso
        → Elementi interattivi (es. gallery di foto dei piatti)
    → Menu come contenitore delle vivande offerte
      - Possibilità di prenotazione direttamente dalla pagina
    → Sale del ristorante e location esterna presentate con immagini e descrizioni brevi
  - Uso di contenuti reali e immagini di qualità
    → Coinvolgimento dell'utente
    → Convinzione a prenotare il ristorante
- Processo di progettazione
  - Collaborazione tra designer, copywriter e team content
    → Garanzia della migliore esperienza utente possibile