1. Progettazione sito ristorante: user personas e contenuti secondari
2. In base alle esigenze delle user personas Giulio e Guido, il sito del ristorante presenta pagine secondarie dedicate a vivande, video, ristorante e location esterna.
3. Per ogni pagina secondaria:
   - Intestazione con titolo e immagine principale
   - Testo descrittivo conciso
   - Elementi interattivi (es. gallery di foto dei piatti)
4. Il menu è il contenitore principale delle vivande offerte, con possibilità di prenotazione direttamente dalla pagina.
5. Le sale del ristorante e la location esterna sono presentate con immagini e brevi descrizioni, per dare un'idea dell'atmosfera e della genuinità del luogo.
6. L'uso di contenuti reali e immagini di qualità è fondamentale per coinvolgere l'utente e convincerlo a prenotare il ristorante.
7. Il processo di progettazione richiede collaborazione tra designer, copywriter e team content per garantire la migliore esperienza utente possibile.