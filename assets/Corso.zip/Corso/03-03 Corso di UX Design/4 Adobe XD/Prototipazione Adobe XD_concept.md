- Creazione di prototipi navigabili con Adobe XD
  - Utilizzo delle proprietà degli elementi (colore, bordo, opacità, arrotondamento)
    → Per creare un file con le dimensioni esatte del viewport del telefono
  - Creazione di componenti e istanze per semplificare la modifica e l'aggiornamento dei prototipi
    → Aggiunta della funzionalità dello scroll e simulazione del prototipo con il triangolino play
  - Aggiunta della funzionalità dello scroll e simulazione del prototipo con il triangolino play
    → Test e presentazione del prototipo al cliente prima di procedere con la realizzazione effettiva.
- Importante:
  - Utilizzare elementi base e senza grafica iniziale per creare il prototipo
    → Sostituire le immagini con box grigi o utilizzare immagini vere per valutare l'efficacia del prototipo
      → Test e presentazione del prototipo al cliente prima di procedere con la realizzazione effettiva.
- Principali concetti:
  - Creazione di un file con le dimensioni esatte del viewport del telefono
    → Utilizzo delle proprietà degli elementi (colore, bordo, opacità, arrotondamento)
      → Creazione di componenti e istanze per semplificare la modifica e l'aggiornamento dei prototipi
        → Aggiunta della funzionalità dello scroll e simulazione del prototipo con il triangolino play
          → Test e presentazione del prototipo al cliente prima di procedere con la realizzazione effettiva.