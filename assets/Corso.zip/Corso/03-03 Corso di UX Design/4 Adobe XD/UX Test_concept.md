Il Test nella Progettazione della UX Design: Fase Cruciale per l'Usabilità

    → Il test è una fase fondamentale nel processo di progettazione della UX Design
        → Serve a verificare l'usabilità del prototipo attraverso il feedback di utenti terzi simili alle user personas
            → Aiuta a individuare i punti di frizione e correggere gli intoppi prima del lancio del sito
                → Risparmia tempo e risorse

    → Campione di utenti di test
        → Obiettivi lineari e definiti per i compiti semplici
            → Concentrarsi sulle parti critiche dove ci sono più dubbi in fase di progettazione
                → Ripetere i test solo dopo che l'intervento sul prototipo è stato concluso
                    → Evitare persone coinvolte nel progetto e ripetere lo stesso test con lo stesso utente
                        → Non dimenticare le caratteristiche delle user personas e degli obiettivi durante i test