1. Creazione di prototipi navigabili con Adobe XD
2. Adobe XD permette di creare prototipi interattivi che simulano l'esperienza di navigazione del sito web, facilitando il processo di testing e presentazione al cliente prima di procedere con la realizzazione effettiva.
3. Importante: 
   - Utilizzare elementi base e senza grafica iniziale per creare il prototipo
   - Sostituire le immagini con box grigi o utilizzare immagini vere per valutare l'efficacia del prototipo
4. Principali concetti:
   - Creazione di un file con le dimensioni esatte del viewport del telefono
   - Utilizzo delle proprietà degli elementi (colore, bordo, opacità, arrotondamento)
   - Creazione di componenti e istanze per semplificare la modifica e l'aggiornamento dei prototipi
   - Aggiunta della funzionalità dello scroll e simulazione del prototipo con il triangolino play
   - Test e presentazione del prototipo al cliente prima di procedere con la realizzazione effettiva.