1. Introduzione al UX Design: separare UI e UX

Il corso di progettazione UX si concentra sulla User Experience (UX) e la User Interface (UI), due discipline fondamentali nella progettazione digitale. La differenza tra UX e UI è importante, ma entrambi sono complementari nel creare un'esperienza utente efficace.

2. Sintesi: Progettazione UX e UI come pilastro della progettazione digitale

La User Experience Design (UX) si concentra sulla costruzione dell'esperienza dell'utente, partendo dall'analisi delle persone, la task analysis e l'architettura delle informazioni. Il risultato è un wireframe e un prototipo che simulano l'esperienza di navigazione del sito.

La User Interface (UI) si concentra sulla progettazione grafica, inclusi colori, font e immagine, per creare un aspetto visivo e emotivo che riflette il marchio.

3. Concetti chiave in ordine cronologico:

- L'importanza di separare UX e UI
- Analisi delle personas
- Task analysis
- Architettura delle informazioni
- Progetto dell'intelaiatura e prototipazione
- Importanza del brand nella progettazione UI

4. Ulteriori concetti chiave:

- L'utente medio non esiste, quindi è importante analizzare le persone e i compiti specifici.
- Non trattare l'utente come se fosse stupido; piuttosto, considera il loro tempo e le loro aspettative.
- Utilizza il benchmarking per analizzare la concorrenza e prendere spunti per migliorare.
- Semplicità non significa minimizzare il lavoro; invece, lavora di più per creare un'esperienza utente efficace.
- La UX deve funzionare, mentre la UI riflette il brand.