1. Introduzione al UX Design: separare UI e UX
   - User Experience (UX) e User Interface (UI) sono discipline fondamentali nella progettazione digitale
   - La differenza tra UX e UI è importante, ma entrambi sono complementari

2. Sintesi: Progettazione UX e UI come pilastro della progettazione digitale
   - UX Design si concentra sulla costruzione dell'esperienza dell'utente attraverso analisi delle persone, task analysis e architettura delle informazioni
     → Resultato: wireframe e prototipi che simulano l'esperienza di navigazione del sito
   - UI Design si concentra sulla progettazione grafica, inclusi colori, font e immagine, per creare un aspetto visivo e emotivo che riflette il marchio

3. Concetti chiave in ordine cronologico:
   - Importanza di separare UX e UI
   - Analisi delle personas
   - Task analysis
   - Architettura delle informazioni
   - Progetto dell'intelaiatura e prototipazione
   - Importanza del brand nella progettazione UI

4. Ulteriori concetti chiave:
   - L'utente medio non esiste, quindi è importante analizzare le persone e i compiti specifici
     → Non trattare l'utente come se fosse stupido; piuttosto, considera il loro tempo e le loro aspettative
   - Utilizza il benchmarking per analizzare la concorrenza e prendere spunti per migliorare
   - Semplicità non significa minimizzare il lavoro; invece, lavora di più per creare un'esperienza utente efficace
   - La UX deve funzionare, mentre la UI riflette il brand