1. Creazione di user personas
   - Definizione dettagliata delle user personas
     → Demografiche
     → Interessi
     → Comportamenti di acquisto
     → Motivazioni per scegliere Gusto Nuovo

2. Gelateria "Gusto Nuovo" come caso di studio
   - Riposizionamento sul mercato del delivery
   - Accento sulla qualità degli ingredienti
   - Personalizzazione degli ordini

3. Focalizzazione sulla qualità degli ingredienti
   → Scegliere ingredienti freschi e di alta qualità
   → Differenziazione del prodotto rispetto ai concorrenti

4. Personalizzazione degli ordini
   → Offerta di opzioni per personalizzare i propri gelati
   → Adattamento alle preferenze individuali

5. Target di pubblico per l'analisi delle user personas
   - Interessati ad ordinare gelato presso Gusto Nuovo
     → Utenti abituali del delivery
     → Persone alla ricerca di un'esperienza di acquisto personalizzata

6. Importanza della velocità di consegna
   → Soddisfazione del cliente
   → Fidelizzazione al servizio di delivery

7. Creazione di abitudini e fidelizzazione del cliente
   - Offerte promozionali
   - Programmi di fedeltà
     → Ricompense per ordini ripetuti
     → Incentivi per l'uso del delivery