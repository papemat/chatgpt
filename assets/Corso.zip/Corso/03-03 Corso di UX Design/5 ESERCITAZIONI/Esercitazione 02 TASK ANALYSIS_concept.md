- Task Analysis: Navigazione utente nella gelateria Gusto Nuovo
    - Analisi delle attività da svolgere
        → Relazionato con il caso d'uso della gelateria Gusto Nuovo
            - Caso d'uso per il task
                → Richiede la selezione e l'utilizzo di user personas
                    * Profili di utenti target
                        → Guidati dalla creazione di un brief
                            + Documento che riassume obiettivi e strategie del progetto
                                → Utilizzato per creare diagrammi di flusso
                                    - Rappresentazione visiva delle interazioni tra utente e sistema
                                        → Relazionato con l'interfaccia utilizzata dall'utente
                                            * Parte visibile dell'applicazione o sito web
                                                → Dove avviene la navigazione dell'utente
                                                    - Movimento dell'utente all'interno del sito o applicazione
                                                        → Conduce alla compilazione dell'ordine
                                                            + Attività finale di acquisto
                                                                → Esercitazione 2: selezione e navigazione con due user personas
                                                                    * Deriva dall'esercitazione 1: scelta delle tre user personas