1. Esercitazione UX Design - Card Sorting Gusto Nuovo

2. In questa esercitazione si prosegue con l'analisi UX per il caso studio di Gusto Nuovo, la gelateria immaginata. Dopo aver creato le user personas e fatto una task analysis, gli studenti devono organizzare in modo logico gli item relativi al mondo della gelateria utilizzando il metodo del card sorting. Questa attività richiede concentrazione e coinvolge un campione di almeno 5 persone per aumentare la validità dei risultati.

3. - Creazione delle user personas
- Analisi delle task
- Selezione di almeno 5 partecipanti al card sorting
- Organizzazione degli item in modo logico
- Utilizzo del metodo del card sorting per categorizzare gli elementi
- Raffinamento dell'organizzazione degli item
- Condivisione dei risultati con il gruppo e rifinitura

4. Gli studenti, dopo aver riletto il brief di Gusto Nuovo, devono:
   - Identificare tutti gli item che rappresentano il mondo della gelateria
   - Organizzare questi item in modo logico utilizzando il card sorting
   - Coinvolgere un campione di almeno 5 persone per aumentare la validità dei risultati
   - Rifinire l'organizzazione degli item sulla base delle feedback ricevuti

5. Il card sorting è una tecnica utile per:
   - Categorizzare gli elementi in modo logico
   - Identificare le relazioni tra i vari componenti del mondo della gelateria
   - Raffinare la comprensione degli utenti e delle loro esigenze
   - Supportare la creazione di un'esperienza utente migliore

6. Al termine dell'esercitazione, gli studenti dovrebbero essere in grado di:
   - Utilizzare il card sorting per organizzare gli item in modo logico
   - Coinvolgere un campione rappresentativo di persone nella fase di testing
   - Raffinare l'organizzazione degli item sulla base dei feedback ricevuti
   - Applicare le lezioni apprese a future analisi UX

7. L'esercitazione si propone di fornire agli studenti una pratica concreta sul campo del card sorting, mettendo in luce l'importanza di questa tecnica per la creazione di un'esperienza utente migliore e il coinvolgimento attivo degli utenti nella fase di design.