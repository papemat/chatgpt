Titolo: L'esercitazione n.1 dei UX Design: Creazione di User Personas per Gusto Nuovo

Paragrafo di sintesi:
Nell'ambito della prima esercitazione del corso di UX Design, gli studenti vengono invitati a creare almeno 3 user personas che si adattino a un pubblico interessato ad ordinare gelato presso la gelateria immaginaria "Gusto Nuovo". La gelateria si riposiziona sul mercato del delivery, mettendo l'accento sulla qualità degli ingredienti e la personalizzazione degli ordini. Le user personas devono essere ben definite, includere informazioni demografiche, interessi, comportamenti di acquisto e motivazioni per scegliere Gusto Nuovo.

Concetti chiave in ordine cronologico:
1. Creazione di user personas
2. Gelateria "Gusto Nuovo" come caso di studio
3. Focalizzazione sulla qualità degli ingredienti
4. Personalizzazione degli ordini
5. Target di pubblico per l'analisi delle user personas
6. Importanza della velocità di consegna
7. Creazione di abitudini e fidelizzazione del cliente