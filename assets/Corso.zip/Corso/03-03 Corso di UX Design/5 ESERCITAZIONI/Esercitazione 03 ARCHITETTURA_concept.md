1. Ordinamento concetti UX Design
   2. Esercitazione con metodo card sorting
      - Introduzione al card sorting
      - Selezione di almeno 5 partecipanti
         → Utilizzo del campione per guidare la progettazione UX
      - Organizzazione degli item in categorie logiche
         → Focus sull'architettura dell'esperienza utente
         → Applicazione dei risultati al caso della gelateria
         → Importanza delle feedbacks degli utenti nella progettazione UX
      - Preparazione per l'esercizio successivo sulla gelateria Gusto Nuovo
         → Preparazione per l'esercizio successivo senza suggerimenti
   3. Conclusione: il card sorting è un metodo efficace per organizzare e priorizzare i concetti chiave in una progettazione UX, preparando il terreno per la creazione di un'esperienza utente migliore. L'esercitazione si concentra sulla gelateria Gusto Nuovo, ma i principi possono essere applicati a qualsiasi progetto UX.