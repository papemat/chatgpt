Titolo:
Task Analysis: Navigazione utente nella gelateria Gusto Nuovo

Paragrafo di sintesi:
Nella seconda esercitazione di UX Design, si lavora sulla task analysis per la gelateria Gusto Nuovo. Dopo aver selezionato due user personas nell'esercizio precedente, queste vengono fatte navigare e interagire con l'interfaccia del sito web, compilando un ordine per testare l'esperienza utente.

Concetti chiave:
1. Task analysis: analisi delle attività da svolgere
2. Gelateria Gusto Nuovo: caso d'uso per il task
3. User personas: profili di utenti target
4. Brief: documento che riassume obiettivi e strategie del progetto
5. Diagramma di flusso: rappresentazione visiva delle interazioni tra utente e sistema
6. Interfaccia: parte visibile dell'applicazione o sito web utilizzata dall'utente
7. Navigazione: movimento dell'utente all'interno del sito o applicazione
8. Compilazione ordine: attività finale di acquisto
9. Esercitazione 1: scelta delle tre user personas
10. Esercitazione 2: selezione e navigazione con due user personas