Architettura dell'informazione: organizzazione delle informazioni sul sito web

  Definizione degli obiettivi e user personas
    → Elencamento di tutti i concetti da raccontare
      → Scrittura dei concetti su post-it o cards
        → Creazione di un numero di copie corrispondente agli utenti campione coinvolte
          → Richiesta a ciascun utente campione di ordinare i post-it in gruppi liberi o predeterminati
            → Valutazione degli elementi in comune tra i gruppi ordinati dagli utenti
              → Definizione dei gruppi e priorizzazione dei concetti basata su user personas e task analysis
                → Organizzazione delle informazioni all'interno del sito web (home page, pagina sul luogo, filosofia, vivande, matrimoni e feste)