Titolo: Introduzione al Processo di UX Design: Definizione degli Obiettivi

Paragrafo di sintesi:
Nella prima lezione di UX Design, gli studenti vengono introdotti al processo di progettazione dell'esperienza utente. Utilizzando due esempi pratici - un sito web per una azienda che produce impianti di filtrazione e un ristorante con orto chilometro zero - viene mostrato come definire gli obiettivi del sito in base ai valori e alle caratteristiche distintive dell'azienda o dell'attività. Gli studenti apprendono l'importanza di presentare adeguatamente il soggetto, sottolineare i suoi punti di forza e invitare all'azione desiderata (contatto, prenotazione).

Concetti chiave:
1. Definizione degli obiettivi
2. Presentazione del soggetto
3. Sottolineatura dei valori e delle caratteristiche distintive
4. Invito all'azione (contatto, prenotazione)
5. Esempi pratici: sito B2B per azienda di impianti e ristorante con orto chilometro zero
6. Utilizzo di matita, blocco schizzi, post-it e programma di prototipazione XD di Adobe
7. Importanza della ricerca e del metodo di progetto anche in esempi apparentemente scontati e banali