Raccolta dati qualitativa: Interviste a domande aperte
    → Importante fonte di informazioni per la creazione di un sito web
        → Ottiene risposte dettagliate e in profondità su come i potenziali utenti interagiranno con il sito
            → Potenziali utenti
                → Esempi: Aziende B2B, Ristoranti
                    → Aziende B2B
                        → Esigenze specifiche
                            → Caratteristiche del sito web da evidenziare
                    → Ristoranti
                        → Esigenza di mostrare menu e opzioni di ordinazione
                            → Caratteristiche del sito web da evidenziare
            → User personas
                → Identificare gruppi di utenti con bisogni specifici
                    → Guida la progettazione del sito web
            → Analisi dei dati
                → Determina quali caratteristiche devono essere incluse nel sito web
                    → Informazioni raccolte durante le interviste a domande aperte