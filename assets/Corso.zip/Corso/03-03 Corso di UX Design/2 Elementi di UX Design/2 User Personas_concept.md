- Profilazione dell'utente: strategie per il design UX
  - Creazione di profili utente (user personas) immaginari che rappresentano gruppi reali di utenti
    → Identificazione dell'intento e delle aspettative dell'utente quando interagisce con il sito o l'azienda
      → Considerazione del contesto in cui l'utente utilizza il sito (dispositivo, luogo, scenario competitivo)
        → Individuazione dei desiderata (ciò che gli utenti vogliono) e dei pain points (le note dolenti, ciò di cui hanno paura o che non vogliono)
          → Studio delle caratteristiche demografiche e antropologiche degli utenti, come età, sesso, livello di istruzione, reddito e cultura
            → Utilizzo di metodologie sia quantitative (sondaggi online) sia qualitative (interviste aperte) per acquisire dati rappresentativi del target
              → Scegliere un campione rappresentativo per le interviste qualitative, spesso con l'aiuto dell'imprenditore o proprietario del business
                → Utilizzo di strumenti come Google Forms per creare sondaggi quantitativi e raccogliere risposte anonime