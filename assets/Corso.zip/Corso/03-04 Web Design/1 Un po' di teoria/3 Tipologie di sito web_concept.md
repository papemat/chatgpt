Tipi di siti web:
├── Siti multipage
│   ├── Composto da più pagine
│   └── Ogni pagina con uno scopo specifico
└── Siti one-page
    ├── Una sola pagina lunga
    └── Contiene tutti i contenuti necessari

Principali concetti:
├── Siti multipage
│   └── Più pagine, ogni pagina con uno scopo specifico
└── Siti one-page
    └── Una sola pagina lunga, contenente tutti i contenuti

Bullets:
├── Siti multipage: più pagine, ogni pagina con uno scopo specifico
└── Siti one-page: una sola pagina lunga, contenente tutti i contenuti