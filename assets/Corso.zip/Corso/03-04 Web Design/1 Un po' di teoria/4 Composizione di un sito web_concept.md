- Struttura e elementi di un sito web
  - Intestazione (header)
    - Contiene il menu di navigazione
    - Include il logo del sito
  - Contenuto
    - Testo
    - Immagini
    - Form
    - Altri elementi interattivi
  - Piede di pagina (footer)
    - Informazioni come privacy policy, contatti e copyright
  - Struttura HTML
    - head
      - Metadati e informazioni non visualizzate
    - body
      - Elementi visibili

- Siti web multipagina, OnePage e landing page
  → Differenze nella struttura e nel menu di navigazione
    - Sito multipagina
      → Intestazione (header) e piede di pagina (footer) ripetuti su tutte le pagine
    - OnePage o landing page
      → Intestazione (header) e piede di pagina (footer) definiscono l'intera pagina
        → Menu di navigazione all'interno della stessa pagina