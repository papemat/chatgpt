- Web: rete globale di interconnessione tra computer e server
  - Accessibile tramite client (telefoni, smartphone, laptop, computer)
  - Connettività globale chiamata World Wide Web

  - Modello client-server:
    - Client richiede servizi/informazioni al server
    - Server fornisce le risorse richieste dai clienti

- Ruolo del server:
  - Condivisione delle informazioni
  - Gestione degli accessi
  - Sicurezza dei dati (accesso limitato, conservazione nel tempo)

- Gestione logica del sistema:
  - Immagazzinamento e richiamo dei dati dal server quando richiesto dal client

- Client:
  - Elemento meno complesso rispetto al server
  - Collegamento al server tramite interfaccia di comunicazione standardizzata

- Comunicazione tra client e server:
  - Avviene attraverso protocolli (es. HTTP)
    - Stabiliscono regole per il corretto scambio di informazioni tra client e server