1. L'ipertesto nel web: linguaggi, CMS e personalizzazione

2. In questo capitolo, verranno esplorati i concetti chiave dell'ipertesto nel contesto del web, tra cui:
- Definizione di ipertesto e differenze rispetto ai testi tradizionali
- Utilizzo degli iperlink per creare percorsi di navigazione non lineari
- Linguaggi di markup (HTML) e stile (CSS) per la realizzazione di siti web
- Sistemi di gestione del contenuto (CMS) come WordPress, Joomla e Drupal
- Pro e contro dell'utilizzo di CMS rispetto a codice personalizzato

3. Concetti chiave in ordine cronologico:
- Definizione di ipertesto: testo non lineare con possibilità di lettura casuale
- Siti web basati su protocolli come HTTP/HTTPS
- Linguaggi di markup (HTML), stile (CSS) e interattività (JavaScript)
- Utilizzo di CMS per la realizzazione di siti web senza conoscenza del codice
- Pro e contro dell'utilizzo di WordPress rispetto a codici personalizzati
- Importanza della SEO e indicizzazione nei siti web, sia con CMS che con codice personalizzato