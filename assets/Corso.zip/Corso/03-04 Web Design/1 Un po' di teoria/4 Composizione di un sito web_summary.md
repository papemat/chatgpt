1. Struttura e elementi di un sito web

2. In questa lezione, abbiamo esplorato i principali elementi e la struttura di un sito web, sia multipagina che OnePage o landing page. Abbiamo visto come l'intestazione (header) e il piede di pagina (footer) siano gli elementi fissi all'interno del sito, mentre il contenuto varia a seconda della tipologia di pagina. In un sito multipagina, questi elementi si ripetono su tutte le pagine, mentre in un OnePage o una landing page, essi definiscono l'intera pagina.

3. Elementi chiave:
   - Intestazione (header): parte superiore del sito che contiene il menu di navigazione e il logo
   - Contenuto: sezione principale della pagina contenente testo, immagini, form e altri elementi interattivi
   - Piede di pagina (footer): sezione inferiore del sito contenente informazioni come privacy policy, contatti e copyright
   - Struttura HTML: head (contiene metadati e informazioni non visualizzate) e body (contiene elementi visibili)
   - Siti web multipagina, OnePage e landing page: differenze nella struttura e nel menu di navigazione