1. Introduzione al Web: funzionamento, protocolli e sicurezza

2. Il web rappresenta una rete fitta di interconnessioni tra computer e server, consentendo l'accesso a informazioni da parte dei client (telefoni, smartphone, laptop, computer). Questa connettività globale prende il nome di World Wide Web.

3. Il sistema funziona su un modello client-server, dove i client richiedono servizi/informazioni al server, che ne è l'unico a fornire tali risorse.

4. Il ruolo del server comprende la condivisione delle informazioni, gestione degli accessi, mantenimento della sicurezza dei dati (accesso limitato solo agli autorizzati e conservazione nel tempo).

5. La gestione logica del sistema si occupa di come i dati vengono immagazzinati e richiamati dal server quando il client lo richiede.

6. Il client è un elemento meno complesso rispetto al server, collegandosi a esso tramite un'interfaccia di comunicazione standardizzata.

7. La comunicazione tra client e server avviene attraverso protocolli (ad esempio HTTP), che stabiliscono regole per il corretto scambio di informazioni tra i due elementi.