1. Tipi di siti web: Multipage vs One-page

In questo video, vengono presentate le principali tipologie di siti web, distinguendo tra multipage e one-page. Il concetto chiave è che un sito multipage è composto da più pagine, ognuna con un suo scopo specifico, mentre un sito one-page è costituito da una sola pagina lunga, che include tutti i contenuti necessari.

2. Principali concetti:
- Siti multipage: più pagine, ogni pagina con uno scopo specifico
- Siti one-page: una sola pagina lunga, contenente tutti i contenuti
- Landing page: pagina realizzata per un obiettivo specifico (vendita, iscrizioni, sottoscrizioni)
- Eventi del mouse e della tastiera: click, doppio click, tasto destro, tasto sinistro, movimento del mouse, key down, key up, key press
- Swipe e zoom su schermo touchscreen (smartphone)
- Regola empirica: pagina non dovrebbe scorrere più di una e mezza vista

3. Bullets:
- Siti multipage: più pagine, ogni pagina con uno scopo specifico
- Siti one-page: una sola pagina lunga, contenente tutti i contenuti
- Landing page: pagina realizzata per un obiettivo specifico (vendita, iscrizioni, sottoscrizioni)
- Eventi del mouse e della tastiera: click, doppio click, tasto destro, tasto sinistro, movimento del mouse, key down, key up, key press
- Swipe e zoom su schermo touchscreen (smartphone)
- Regola empirica: pagina non dovrebbe scorrere più di una e mezza vista