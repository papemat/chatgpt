1. Installazione del tema Divi su WordPress
2. Paragrafo di sintesi:
Nelle lezioni precedenti abbiamo imparato a comprare un hosting Easy Linux su Aruba e come installare un WordPress. Ora, per migliorare ulteriormente il sito web, è necessario installare il tema Divi, che richiede un acquisto. Dopo aver selezionato l'offerta annuale di 89 dollari, si procede con la registrazione su Elegant Themes e si effettua il pagamento tramite carta di credito o PayPal. Una volta completata la registrazione, si scarica il file .zip del tema Divi e si connette al pannello di controllo WordPress per installarlo e attivarlo.
3. Bullet point:
- Acquisto del tema Divi
- Selezione dell'offerta annuale
- Registrazione su Elegant Themes
- Effettuazione del pagamento
- Scaricamento del file .zip del tema Divi
- Installazione e attivazione del tema Divi in WordPress