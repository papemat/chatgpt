Creazione pagine su Wordpress
  → Accesso all'area di amministrazione
      - Loggatura con username e password
      - Visualizzazione del menu a sinistra se si è amministratori
  → Aggiunta di una nuova pagina
      - Clic su "Pagina" nel menu
      - Selezionare "Aggiungi Pagina"
      - Inserimento titolo e contenuto nella schermata editor
  → Pubblicazione della pagina
      - Selezione del template desiderato (opzionale)
      - Clic sulla voce "Pubblica" per rendere la pagina visibile sul sito
  → Gestione della home page
      - Modifica dell'attributo "Home Page"
      - Selezione di una pagina come home page principale
  → Duplicazione di pagine esistenti
      - Selezionare la pagina da duplicare
      - Clic su "Aggiungi Pagina" per creare una nuova pagina identica
  → Eliminazione di una pagina
      - Selezionare la pagina da eliminare
      - Clic sul cestino per rimuovere la pagina dall'elenco