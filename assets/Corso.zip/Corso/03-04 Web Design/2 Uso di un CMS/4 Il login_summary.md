1. Introduzione al WordPress: Log-in e prima navigazione

2. In questa lezione, Speaker 1 guida i partecipanti attraverso il processo di accesso al loro sito WordPress recentemente installato. Dopo aver acquistato l'hosting Linux su Aruba e installato WordPress con il tema Divi, Speaker 1 spiega come accedere alla dashboard di WordPress tramite wp-login.php. Successivamente, i partecipanti scoprono come navigare nella parte front-end del sito utilizzando la barra degli strumenti in alto.

3. Accesso al sito WordPress
4. Utilizzo della barra di ricerca per inserire il nome di dominio
5. Accedere alla dashboard tramite wp-login.php
6. Esplorazione della dashboard e dei menu laterali
7. Introduzione al tema Divi e Visual Builder

8. Log-out e accesso al profilo utente tramite link diretto

9. Navigazione tra diverse schede e confronto del sito front-end con il back-end

10. Presentazione degli strumenti della barra in alto per modifiche veloci sul front-end