1. Introduzione al WordPress: Log-in e prima navigazione
   - Accesso al sito WordPress
     -> Utilizzo della barra di ricerca per inserire il nome di dominio
   - Accedere alla dashboard tramite wp-login.php
     -> Esplorazione della dashboard e dei menu laterali
   - Introduzione al tema Divi e Visual Builder
     -> Log-out e accesso al profilo utente tramite link diretto
     -> Navigazione tra diverse schede
     -> Confronto del sito front-end con il back-end
   - Presentazione degli strumenti della barra in alto per modifiche veloci sul front-end

2. Accesso al sito WordPress
   -> Utilizzo della barra di ricerca per inserire il nome di dominio
   -> Accedere alla dashboard tramite wp-login.php
     -> Esplorazione della dashboard e dei menu laterali

3. Utilizzo della barra di ricerca per inserire il nome di dominio
   -> Accedere alla dashboard tramite wp-login.php
     -> Esplorazione della dashboard e dei menu lateriali