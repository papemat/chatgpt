Acquisto dominio e servizio hosting
    → Scegliere il nome del dominio e l'estensione appropriata
        → Selezionare un piano di hosting Linux con database MySQL
            → Installare WordPress utilizzando l'installer fornito da Aruba
                → Configurare il database, inserendo le informazioni fornite da Aruba
                    → Accedere al sito web attraverso la pagina di amministrazione WordPress (admin) o utilizzando un'altra URL fornita