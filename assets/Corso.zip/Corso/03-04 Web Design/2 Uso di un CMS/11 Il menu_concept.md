1. Creazione e Personalizzazione del Menu in WordPress
   - Accedere al pannello di controllo del menu tramite l'interfaccia di amministrazione di WordPress
     → Creare un nuovo menu
   - Creare un nuovo menu
     → Scegliere la posizione del menu (header, footer o secondario)
   - Scegliere la posizione del menu (header, footer o secondario)
     → Aggiungere pagine al menu utilizzando il drag-and-drop
   - Aggiungere pagine al menu utilizzando il drag-and-drop
     → Rinominare i link delle voci del menu
   - Rinominare i link delle voci del menu
     → Aggiungere link personalizzati
   - Aggiungere link personalizzati
     → Creare sottomenu
   - Creare sottomenu
     → Gestire la posizione dei menu all'interno del tema