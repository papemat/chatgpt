1. Acquisto del tema Divi
   → Selezione dell'offerta annuale (89 dollari)
   → Registrazione su Elegant Themes
      → Effettuazione del pagamento (carta di credito o PayPal)
2. Installazione del tema Divi in WordPress
   → Scaricamento del file .zip del tema Divi
   → Connessione al pannello di controllo WordPress
      → Installazione del tema Divi
      → Attivazione del tema Divi