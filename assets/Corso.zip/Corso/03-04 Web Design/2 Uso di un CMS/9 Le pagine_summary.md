1. Creazione pagine su Wordpress
2. Questa lezione mostra come creare e gestire pagine in un sito WordPress, utilizzando l'area di amministrazione del sito. Vengono spiegate le fasi per aggiungere una nuova pagina, personalizzare il template, selezionare la home page e duplicare pagine esistenti.
3. Accesso all'area di amministrazione
- Loggatura con username e password
- Visualizzazione del menu a sinistra se si è amministratori
2. Aggiunta di una nuova pagina
- Clic su "Pagina" nel menu
- Selezionare "Aggiungi Pagina"
- Inserimento titolo e contenuto nella schermata editor
3. Pubblicazione della pagina
- Selezione del template desiderato (opzionale)
- Clic sulla voce "Pubblica" per rendere la pagina visibile sul sito
4. Gestione della home page
- Modifica dell'attributo "Home Page"
- Selezione di una pagina come home page principale
5. Duplicazione di pagine esistenti
- Selezionare la pagina da duplicare
- Clic su "Aggiungi Pagina" per creare una nuova pagina identica
6. Eliminazione di una pagina
- Selezionare la pagina da eliminare
- Clic sul cestino per rimuovere la pagina dall'elenco