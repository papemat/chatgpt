- System 1: Il Potere della Storia nel Marketing
  - Problemi processati dal System 1
    - Problemi sociali
      → Bisogno di accettazione
      → Dominio
    - Problemi pratici
      → Soddisfazione dei bisogni quotidiani
    - Bisogni trasformativi
      → Trasformazione della vita
  - Il sistema 1 è costantemente bombardato da bisogni sociali, pratici e trasformativi, che riflettono la natura umana di desiderio di accettazione, dominio o semplice soddisfo dei bisogni quotidiani.
  - La branding strategy deve proporre argomenti per tre categorie di soluzioni: pratiche, trasmutative e trasformative
    → Soluzioni pratiche
      → Risoluzione immediata dei problemi
    → Soluzioni trasmutative
      → Cambiamento di identità o status
    → Soluzioni trasformative
      → Modifica significativa della vita
  - Il storytelling è il metodo principale per trasformare prodotto e bisogno in soluzione attraverso la creazione di significato e l'uso del cammino dell'eroe come schema base.
    → Creazione di significato
      → Connettere il prodotto al cliente
    → Cammino dell'eroe
      → Schema base per il storytelling
  - Quando un pain point viene creato dal problema, il brand entra in gioco fornendo al cliente un superpotere o una spada per risolvere il problema in modo rapido ed efficace, proiettando anche una vita migliore di quella precedente.
    → Superpotere/Spada
      → Soluzione immediata al problema
    → Proiezione di una vita migliore
      → Motivazione ad acquistare il prodotto