1. System 1: Il Potere della Storia nel Marketing

2. In questo capitolo, vengono esplorati i meccanismi del sistema 1 e come il branding strategy possa utilizzare il potere della storia per risolvere i problemi dei clienti. Gli esempi dello spritz, dell'auto e del martello illustrano come i prodotti possano essere trasformati in soluzioni attraverso la strategia di branding.

3. Problemi processati dal System 1:
   - Problemi sociali
   - Problemi pratici
   - Bisogni trasformativi

4. Il sistema 1 è costantemente bombardato da bisogni sociali, pratici e trasformativi, che riflettono la natura umana di desiderio di accettazione, dominio o semplice soddisfo dei bisogni quotidiani.

5. La branding strategy deve proporre argomenti per tre categorie di soluzioni: pratiche, trasmutative e trasformative.

6. Il storytelling è il metodo principale per trasformare prodotto e bisogno in soluzione attraverso la creazione di significato e l'uso del cammino dell'eroe come schema base.

7. Quando un pain point viene creato dal problema, il brand entra in gioco fornendo al cliente un superpotere o una spada per risolvere il problema in modo rapido ed efficace, proiettando anche una vita migliore di quella precedente.