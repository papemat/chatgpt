La memorizzazione del branding attraverso gli stimoli sensoriali

1. La memorizzazione del branding avviene attraverso la creazione di forti tracce mnemoniche utilizzando diversi tipi di stimoli sensoriali.

   - Gli stimoli sensoriali includono:
     → Il nome del marchio
     → Il logo
     → Le forme visive
     → La grafica
     → Lo spazio fisico
     → La descrizione sotto il logo
     → I suoni e la musica
     → Eventualmente anche profumi

2. Quando un marchio è stato esposto ripetutamente a questi stimoli coerenti e distintivi nel tempo, il cervello del cliente può ricordare il marchio anche solo attraverso l'esposizione ad alcuni di questi stimoli.

3. La memorizzazione avviene principalmente grazie al sistema 1 (processamento automatico) che recupera l'intera traccia mnemonica e la integra con il sistema 2 (processamento consapevole).

4. Un marchio forte può essere recuperato dal cervello del cliente anche tramite la semplice esposizione a:
   - 1 stimolo sensoriale
   - 2 stimoli sensoriali
   - 3 stimoli sensoriali
   e non per forza tutti

5. L'importante è che questi stimoli attivino una traccia mnemonica che arrivi al sistema 2 e faccia si che la persona si ricordi del nostro marchio rispetto a quello dei nostri concorrenti.