- Vendita migliore e marketing come strumento per rendere la vita più facile ai venditori
  - Marketing: strumento per vendere meglio
    → Rende la vita più facile ai venditori
      → Porta i clienti

- Importanza di comprendere il funzionamento della mente dei clienti
  - Comprendere il cervello dei clienti
    → Aiuta a vendere meglio

- Creazione di una trasposizione del prodotto che sia comprensibile per il cervello dei clienti
  - Trasposizione del prodotto
    → Comprensibile per il cervello dei clienti
      → Vendita efficace

- Unione tra System 1 e visione psicologica nella strategia di branding
  - System 1
    → Visione psicologica
      → Strategia di branding

- Focalizzazione sulla lungo termine e costruzione del valore del marchio (brand equity)
  - Lungo termine
    → Costruzione del valore del marchio
      → Brand equity

- Creazione di argomenti pratici per il marketing operativo, basati su una chiara strategia di branding
  - Argomenti pratici
    → Marketing operativo
      → Basati su una strategia di branding chiara

- Combinare il problema del cliente, il prodotto venduto e la trasposizione per creare un messaggio pubblicitario efficace
  - Problema del cliente
    → Prodotto venduto
      → Trasposizione
        → Messaggio pubblicitario efficace