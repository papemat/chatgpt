Branding Strategy
├── Costruzione del Marchio e Creazione di Argomenti per il Marketing Operativo
│   ├── Francesco Galvani guida gli studenti attraverso la strategia di branding
│   │   └── Fornisce strumenti necessari per creare un marchio forte e una strategia di marketing efficace
│   ├── Obiettivo: far funzionare il marketing al passo con il mondo reale
│   └── Creare argomenti per il marketing operativo (media, pubblicità e content)
└── Senza una strategia di branding, il resto del marketing risulterà inefficace

Concetti chiave
├── Il marchio è l'unico artefatto cognitivo che può essere processato dal cervello umano
├── La mente umana si evolve in un ambiente naturale ricco di segnali sensoriali
├── I marchi devono risolvere problemi e proiettare sogni per i clienti
│   └── Comunicazione deve concentrarsi su stimoli sensoriali semanticamente coerenti piuttosto che sui prodotti o servizi
└── La strategia di costruzione del marchio si compone di tre passaggi:
    ├── Analizzare
    ├── Progettare
    └── Creare stimoli sensoriali, comprendere la psicologia dei clienti e focalizzarsi sul target specifico