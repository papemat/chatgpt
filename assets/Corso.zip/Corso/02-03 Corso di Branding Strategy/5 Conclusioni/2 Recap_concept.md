Branding Strategy
├── Gironi del Brand
│   ├── Stimoli sensoriali
│   ├── Problemi e soluzioni
│   └── Sogni e realizzazione
└── Cervello subcognitivo dei clienti → Memorizzazione e traccia mnemonica

Memorizzazione e traccia mnemonica
├── Funzionamento della memoria e del retrieval dell'informazione
└── Deep Network e storytelling

Deep Network e storytelling
├── Pain point
└── Deep Need Map

Problemi e soluzioni → Pain point

Sogni e realizzazione → Deep Need Map

Gironi del Brand
├── Stimoli sensoriali
│   └── Cervello subcognitivo dei clienti
├── Problemi e soluzioni
│   ├── Pain point
│   └── Deep Need Map
└── Sogni e realizzazione
    └── Deep Need Map

Definizione chiara dei clienti di target → Cervello subcognitivo dei clienti