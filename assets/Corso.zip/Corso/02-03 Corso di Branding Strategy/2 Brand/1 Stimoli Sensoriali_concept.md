1. Multisensorialità nella creazione di marchi forti → La multisensorialità è fondamentale nella creazione di marchi forti.

2. Memorizzazione attraverso l'associazione di stimoli diversi e multisensoriali → Il cervello umano memorizza informazioni attraverso l'associazione di stimoli diversi e multisensoriali.

3. Causa-effetto o condizioni per associare gli stimoli → L'uso della causa-effetto o delle condizioni per associare gli stimoli può migliorare la memorizzazione.

4. Distinzione dei marchi attraverso grafica, suoni, packaging, comunicazione e odori → I marchi più forti si distinguono dagli altri attraverso grafica, suoni, packaging, comunicazione e odori.

5. Ripetizione degli stessi pattern non efficace → La ripetizione degli stessi pattern non funziona nel sollecitare il cervello umano in modo efficace.

6. Tempo necessario per imparare e assorbire informazioni nuove → Il cervello richiede tempo per imparare e assorbire informazioni nuove ogni volta che vengono presentate.

7. Presentazione di stimoli coerenti semanticamente e distinti dai competitor → È necessario presentare stimoli coerenti semanticamente e distinti da quelli dei competitor per memorizzare i marchi efficacemente.