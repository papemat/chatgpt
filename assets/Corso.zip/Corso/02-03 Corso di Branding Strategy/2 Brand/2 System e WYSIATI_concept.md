1. Appello al System One
   - Processa informazioni rapidamente
     → Utilizza impressioni, intuizioni e stereotipi
       → Guida le decisioni

2. System Two
   - Richiede più energia e riflessione
     → Contrapposto a System One

3. System One
   - Costantemente attivo
     → Consuma meno energia rispetto al System Two

4. Utilizzare il System One nel marketing
   - Connettersi emotivamente con il pubblico
     → Far risuonare le narrazioni del marketing con le associazioni e le emozioni preesistenti del target

5. Regola "There is"
   - Viviamo nel qui e ora (importanza di rispettare questa regola)
     → Crea informazioni memorizzabili e facilmente riproducibili