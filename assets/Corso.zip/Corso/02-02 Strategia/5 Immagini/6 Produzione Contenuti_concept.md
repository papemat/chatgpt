- Diventare Produttori di Contenuti per Aumentare il Valore Percepito
  - Aumentare il valore percepito del prodotto o servizio
    - Focalizzare l'attenzione sulla produzione digitale dei contenuti
      → Attenersi agli intenti di ricerca per creare soluzioni specifiche
        → Produrre contenuti come soluzioni specifiche a desideri di mercato
  - Costruire una community di fan entusiasti
    - Creare un format di divulgazione dei contenuti
      → Aumentare il valore percepito del prodotto o servizio
  - Promuovere la diffusione del prodotto o servizio attraverso referral
    → Costruire una community di fan entusiasti