- Soluzioni specifiche
  - Prodotti o servizi che rispondono a esigenze precise del cliente
    → Principio di autorità
      - Credibilità acquisita attraverso esperienza e conoscenza nel settore
        → Costruzione dell'autorità
          - Comunicazione costante
            → Ottengo risultati
              → Creazione di relazioni pubbliche
                → Aumenta il valore percepito della soluzione offerta
                  → Riprova sociale
                    - Giudizi positivi di terzi sul valore di un prodotto o servizio
                      → Cambio di prospettiva
                        - Passaggio dalla diffidenza al credere nel valore offerto