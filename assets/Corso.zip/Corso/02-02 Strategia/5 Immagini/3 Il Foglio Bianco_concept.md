L'errore del foglio bianco nella comunicazione
    → L'errore del foglio bianco: metafora per indicare l'inadeguatezza di iniziare una comunicazione da zero
        → Captare il desiderio di mercato: identificare le richieste specifiche delle persone
            → Intenti di ricerca delle persone: scoprire cosa le persone stanno cercando e come possono essere soddisfatte
        → Rielaborare le richieste: adattare le soluzioni alle esigenze del pubblico
            → Non inventare nulla: non creare qualcosa ex novo, ma piuttosto rielaborare ciò che già esiste per adattarlo alle necessità del mercato
    → Strutturare un piano di comunicazione: organizzare la comunicazione in base alle esigenze e ai desideri del target
        → Pianificazione della comunicazione: organizzare la strategia di comunicazione in base ai bisogni e desideri del target