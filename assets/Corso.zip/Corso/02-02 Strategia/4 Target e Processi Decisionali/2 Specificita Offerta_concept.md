Costruire una soluzione specifica per il mercato
    → Parola chiave: Identificare desideri del mercato, valore percepito e concorrenza
        - Focalizzare la strategia su offrire una soluzione a un desiderio di mercato
        - Aumentare il valore percepito per il cliente potenziale
        - Capire se c'è un riscontro sul mercato per il prodotto o servizio
            → Assicurarsi che ci sia un mercato con concorrenti correlati
        - Creare una specificità nel prodotto o servizio per prendere una fetta di mercato