- Intercettare il desiderio di mercato e costruire soluzioni specifiche
  - Il processo di passaggio da potenziale cliente a fan, attraverso i gradini del calore, è fondamentale per aumentare il valore percepito e le vendite.
    - Potenziali clienti: persone in target che potrebbero acquistare il prodotto o servizio
      → Prospect: persone che hanno avuto conoscenza del marchio o della pubblicità, ma non hanno ancora acquistato
        → Acquirente: persona che ha effettuato un acquisto del prodotto o servizio
          → Cliente: acquirenti che hanno ripetuto l'acquisto
            → Fan: persone molto soddisfatte del prodotto/servizio, pronte a fare referenze
              → Referral: persone che acquistano per consiglio di un fan
                → Perso: clienti che non hanno più acquistato il prodotto o servizio, ma possono essere riattivati con un contatto appropriato