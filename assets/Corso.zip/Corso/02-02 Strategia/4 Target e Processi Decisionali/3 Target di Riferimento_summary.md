1. Intercettare il desiderio di mercato e costruire soluzioni specifiche

2. Il processo di passaggio da potenziale cliente a fan, attraverso i gradini del calore, è fondamentale per aumentare il valore percepito e le vendite.

3. Potenziali clienti: persone in target che potrebbero acquistare il prodotto o servizio
4. Prospect: persone che hanno avuto conoscenza del marchio o della pubblicità, ma non hanno ancora acquistato
5. Acquirente: persona che ha effettuato un acquisto del prodotto o servizio
6. Cliente: acquirenti che hanno ripetuto l'acquisto
7. Fan: persone molto soddisfatte del prodotto/servizio, pronte a fare referenze
8. Referral: persone che acquistano per consiglio di un fan
9. Perso: clienti che non hanno più acquistato il prodotto o servizio, ma possono essere riattivati con un contatto appropriato