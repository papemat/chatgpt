1. Strategia di marketing sui social media: piattaforme e contenuti ottimizzati

2. In questo paragrafo, l'oratore discute le diverse piattaforme sociali e come ciascuna possa essere utilizzata per raggiungere obiettivi specifici di marketing. YouTube, Facebook, Instagram, LinkedIn, Podcast e Google sono esaminati in termini di contenuti più adatti, durata dei video e target di pubblico.

3. Piattaforme sociali:
   - YouTube: piattaforma ideale per contenuti lunghi e specifici
   - Facebook e Instagram: piattaforme per contenuti brevi e attenzione a breve termine
   - LinkedIn: piattaforma B2B per connessioni professionali e contenuti mirati
4. Contenuti ottimizzati:
   - Lunghezza dei video: YouTube consiglia video più lunghi, mentre Facebook e Instagram richiedono contenuti brevi
   - Target di pubblico: identificare il target specifico per un marketing più efficace
5. Podcast e Google:
   - Podcast: formato audio che permette ascolto durante altre attività
   - Google: motore di ricerca per trovare contenuti rilevanti e ottimizzare la visibilità online

6. L'oratore sottolinea l'importanza di comprendere le differenze tra le piattaforme sociali e di adattare i propri contenuti in base a questi fattori per raggiungere un pubblico più ampio e specifico.