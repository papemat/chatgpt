Google → Motore di ricerca più utilizzato al mondo
SEO (Search Engine Optimization) → Indicizzazione di un sito web
SEO → Creazione di contenuti specifici e adatti a piacere a Google
Gli spider di Google → Esplorano i contenuti web
Spider di Google → Valutano la qualità e le caratteristiche dei contenuti
Valutazione dei contenuti → Assegnazione di punteggi e posizionamenti
Obiettivo dell'SEO → Creare contenuti ottimizzati che rispondono alle ricerche degli utenti
Contenuti ottimizzati → Aumentano la visibilità del sito web