Social Network: Un'Introduzione al Marketing Digitale

  I social network sono diventati strumenti fondamentali per il marketing digitale

    → Permettono di raggiungere target specifici in modo economico rispetto ai media tradizionali

      Facebook, ad esempio, è un concessionario pubblicitario che offre la possibilità di mostrare inserzioni a un pubblico specifico a prezzi irrisori

        → Questo perché Facebook intercetta domande latenti utilizzando informazioni come le preferenze degli utenti

  Concetti chiave:

    - I social network sono diventati strumenti essenziali per il marketing digitale
    - Facebook è un concessionario pubblicitario che permette di raggiungere target specifici a costi contenuti
    - La copertura organica dei social è inversamente proporzionale al numero di persone che vedono gli annunci
      → I social network mirano a mantenerti sulla piattaforma per mostrarti il giusto numero di pubblicità senza risultare eccessivamente invasive