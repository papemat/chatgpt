1. Crea un podcast su allenamento pettorali
2. Synthesis: In questo spezzone, l'oratore parla dell'opportunità di creare un podcast specifico per l'allenamento dei pettorali o di estrarre l'audio da video YouTube esistenti sullo stesso argomento. Sottolinea l'importanza di avere grafiche di qualità per attirare l'interesse del pubblico.

3. - Creare un podcast specifico per l'allenamento pettorali
- Estrarre l'audio da video YouTube esistenti
- Utilizzare contenuti a parte se non si è a proprio agio con i video
- Iniziare a creare contenuti partendo dalle informazioni già acquisite
- Lavorare bene sulle grafiche per attirare l'interesse del pubblico
- Utilizzare Photoshop per ottenere grafiche di qualità
- Seguire un corso di Photoshop per migliorare le abilità grafiche