Crea un podcast su allenamento pettorali
    → Creare un podcast specifico per l'allenamento pettorali
        → - Estrarre l'audio da video YouTube esistenti
            → Utilizzare contenuti a parte se non si è a proprio agio con i video
        → Iniziare a creare contenuti partendo dalle informazioni già acquisite
    → Estrarre l'audio da video YouTube esistenti
        → - Utilizzare contenuti a parte se non si è a proprio agio con i video
    → Lavorare bene sulle grafiche per attirare l'interesse del pubblico
        → - Utilizzare Photoshop per ottenere grafiche di qualità
            → Seguire un corso di Photoshop per migliorare le abilità grafiche