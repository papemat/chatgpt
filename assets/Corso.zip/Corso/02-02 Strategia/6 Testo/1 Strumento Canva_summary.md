1. Creazione di grafiche con Canva: esempio per un articolo sul blog

2. In questo estratto, il preparatore tecnico illustra come utilizzare Canva, uno strumento gratuito per la creazione di grafiche, per generare una miniatura per un articolo sul proprio blog. Canva offre funzionalità a pagamento ma è principalmente gratuito e utile per chi desidera creare grafiche rapidamente.

3. Bullet punti:
   - Canva è uno strumento gratuito per la creazione di grafiche.
   - Può essere utilizzato per generare miniature per articoli sul blog o video su YouTube.
   - Offre funzionalità a pagamento, ma il suo uso principale è gratuito.
   - Canva fornisce molti aiuti e framework già fatti per facilitare la creazione di grafiche.
   - È un'ottima soluzione per chi desidera creare grafiche rapidamente.