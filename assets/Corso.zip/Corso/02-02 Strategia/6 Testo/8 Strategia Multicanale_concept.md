Importanza della presenza multicanale
  → Utilizzo di YouTube, Facebook, Instagram e altri canali
    → Creazione di contenuti su YouTube, Facebook e Instagram
      → Sfruttamento delle testimonial come strumento di marketing
      → Collaborazioni e partnership con altri soggetti del settore
        → Focalizzazione su un desiderio di mercato specifico
  → Utilizzo di sponsorizzazioni per aumentare l'esposizione
    → Organizzazione di eventi dal vivo per coinvolgere il pubblico