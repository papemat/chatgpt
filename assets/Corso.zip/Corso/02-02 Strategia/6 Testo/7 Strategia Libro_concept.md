- Sindrome del foglio bianco
  - Difficoltà iniziali nel iniziare a scrivere un libro
    → Evitare l'affanno per la partenza da un foglio bianco
      - Possibilità di completare la stesura in tempi rapidi utilizzando il metodo descritto

- Capitoli come intenti di ricerca
  - Strutturazione del libro attorno agli obiettivi di studio
    → Elaborazione dei contenuti su una struttura predefinita
      - Lavorazione dello scheletro

- Conoscenza della materia
  - Requisito fondamentale per scrivere un libro efficace