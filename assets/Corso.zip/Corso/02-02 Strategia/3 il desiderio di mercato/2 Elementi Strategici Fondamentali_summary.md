1. Fondamenti di una strategia di marketing
2. La sintesi del discorso riguarda l'importanza di partire da un desiderio di mercato per creare una soluzione specifica e poi proporre un prodotto o servizio. Il processo richiede di comprendere i reali motivi dietro il desiderio delle persone, come salute, accettazione sociale e autostima.
3. - Desiderio di mercato: le persone sono disposte a pagare per risolvere un problema
- Soluzione specifica: la tua offerta deve soddisfare questo desiderio in modo unico
- Proporre un prodotto o servizio: alla fine, devi presentare una soluzione tangibile
4. - Il mercato è in costante evoluzione, come dimostrato dall'innovazione della lavatrice rispetto al lavaggio a mano
5. - Non inventati oggetti che non esistono, ma asseconda i desideri del mercato con soluzioni specifiche
6. - Le innovazioni inizialmente sono accettate solo dai ricchi prima di diventare accessibili a tutti
7. - Il processo di creazione di una strategia di marketing parte dal desiderio di mercato, passa per la soluzione specifica e si conclude con il prodotto o servizio finale