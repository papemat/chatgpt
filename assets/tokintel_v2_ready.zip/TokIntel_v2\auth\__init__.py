"""
TokIntel v2 - Authentication Module
Gestione autenticazione e autorizzazioni per piattaforme esterne
"""

from .tiktok_oauth import TikTokOAuth

__all__ = ['TikTokOAuth'] 