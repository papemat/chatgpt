# TokIntel v2 – Launcher

## 🚀 Avvio rapido

### Windows

- Doppio click su `launch_tokintel.bat`
- **Oppure** da terminale:
  ```sh
  python streamlit_launcher.py
  ```

### Linux/Mac

- Da terminale:
  ```sh
  bash launch_tokintel.sh
  ```
  oppure
  ```sh
  python3 streamlit_launcher.py
  ```

---

## 🛠️ Troubleshooting

- **UnicodeEncodeError**
  > Imposta la console su UTF-8:
  >
  > ```sh
  > chcp 65001
  > ```
- **streamlit: command not found**
  > Usa:
  >
  > ```sh
  > python -m streamlit run ...
  > ```

---

## 📄 File launcher

- `launch_tokintel.bat`: Avvio rapido per Windows
- `launch_tokintel.sh`: Avvio rapido per Linux/Mac
- `streamlit_launcher.py`: Script universale per lanciare la UI

---

## 🏷️ Badge

- ✅ Tested
- 🌍 Cross-platform
- 📊 UI Ready 