# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [Unreleased]

## [2.0.0] - 2025-07-24
### Added
- Logging avanzato e rotazione log via RotatingFileHandler.
- Test edge-case per scraping (video non trovato, timeout Playwright) e scoring (input vuoto, rumore, categorie ignote).
- Packaging CLI production-grade e supporto `pipx`.
- Automazione test, linting, type-checking (pytest, mypy, flake8, black).
- CI/CD GitHub Actions con badge e upload coverage.
- Refactor, modularizzazione e typing completo dei moduli chiave. 